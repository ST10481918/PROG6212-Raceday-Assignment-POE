// Show the organiser code box only when "Organiser" is chosen on the sign-up page.
(function () {
    var box = document.getElementById('organiserCodeBox');
    if (!box) return;
    document.querySelectorAll('input[name="Role"]').forEach(function (radio) {
        radio.addEventListener('change', function () {
            box.style.display = document.getElementById('roleOrganiser').checked ? '' : 'none';
        });
    });
})();

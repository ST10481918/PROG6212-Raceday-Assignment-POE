namespace RaceDay.Web.Models;

// Shapes of the JSON that the Part 2 API returns. They only carry data - no business logic lives here.

public enum EventType { Run, Walk, Cycle }

public enum EnrolmentStatus { Pending, Confirmed }

public class MessageDto
{
    public string Message { get; set; } = string.Empty;
}

public class LoginDto
{
    public string Token { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public DateTime ExpiresAt { get; set; }
}

public class ProfileDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Surname { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string? EmergencyContact { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public string? ProfilePicture { get; set; }
}

public class EventDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public string Location { get; set; } = string.Empty;
    public double DistanceKm { get; set; }
    public EventType Type { get; set; }
    public int OrganiserId { get; set; }
    public string? BannerImage { get; set; }
    public int EnrolmentCount { get; set; }
}

public class CategoryDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public int EventId { get; set; }
}

public class EnrolResultDto
{
    public string Message { get; set; } = string.Empty;
    public int EnrolmentId { get; set; }
    public int BibNumber { get; set; }
}

public class EnrolmentDto
{
    public int EnrolmentId { get; set; }
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public int ParticipantId { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public int CategoryId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int BibNumber { get; set; }
    public EnrolmentStatus Status { get; set; }
    public DateTime EnrolledAt { get; set; }
}

public class ResultDto
{
    public int EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public int Position { get; set; }
    public int TotalFinishers { get; set; }
    public int BibNumber { get; set; }
    public string ParticipantName { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public TimeSpan FinishTime { get; set; }
}

public class ImageDto
{
    public string Path { get; set; } = string.Empty;
}

public class MediaFile
{
    public byte[] Data { get; set; } = Array.Empty<byte>();
    public string ContentType { get; set; } = "application/octet-stream";
}

using System.ComponentModel.DataAnnotations;

namespace RaceDay.Web.Models;

public class LoginViewModel
{
    [Required(ErrorMessage = "Please enter your email address")]
    [EmailAddress(ErrorMessage = "That doesn't look like a valid email address")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please enter your password")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = string.Empty;

    public string? ReturnUrl { get; set; }
}

public class RegisterViewModel
{
    [Required(ErrorMessage = "Please enter your first name"), StringLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please enter your surname"), StringLength(100)]
    public string Surname { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please enter your email address")]
    [EmailAddress(ErrorMessage = "That doesn't look like a valid email address")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please choose a password")]
    [StringLength(100, MinimumLength = 8, ErrorMessage = "Your password must be at least 8 characters long")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please confirm your password")]
    [Compare(nameof(Password), ErrorMessage = "The two passwords do not match")]
    [DataType(DataType.Password)]
    [Display(Name = "Confirm password")]
    public string ConfirmPassword { get; set; } = string.Empty;

    [Required]
    public string Role { get; set; } = "Participant";

    [Display(Name = "Organiser code")]
    public string? OrganiserCode { get; set; }

    [StringLength(50), Display(Name = "Emergency contact")]
    public string? EmergencyContact { get; set; }

    [DataType(DataType.Date), Display(Name = "Date of birth")]
    public DateTime? DateOfBirth { get; set; }
}

public class ProfileViewModel
{
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string? ProfilePicture { get; set; }

    [Required(ErrorMessage = "Please enter your first name"), StringLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please enter your surname"), StringLength(100)]
    public string Surname { get; set; } = string.Empty;

    [StringLength(50), Display(Name = "Emergency contact")]
    public string? EmergencyContact { get; set; }

    [DataType(DataType.Date), Display(Name = "Date of birth")]
    public DateTime? DateOfBirth { get; set; }
}

public class EventFormViewModel
{
    public int? Id { get; set; }

    [Required(ErrorMessage = "Please enter an event name"), StringLength(150)]
    public string Name { get; set; } = string.Empty;

    [StringLength(2000)]
    public string Description { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please choose the event date and time")]
    [DataType(DataType.DateTime)]
    public DateTime? Date { get; set; }

    [Required(ErrorMessage = "Please enter the location"), StringLength(200)]
    public string Location { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please enter the distance")]
    [Range(0.1, 1000, ErrorMessage = "Distance must be between 0.1 and 1000 km")]
    [Display(Name = "Distance (km)")]
    public double? DistanceKm { get; set; }

    [Display(Name = "Event type")]
    public EventType Type { get; set; }

    [Display(Name = "Banner image")]
    public IFormFile? Banner { get; set; }

    public string? ExistingBanner { get; set; }
}

public class EventFilter
{
    public string? Search { get; set; }
    public EventType? Type { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public bool IncludePast { get; set; }
}

public class HomeViewModel
{
    public EventFilter Filter { get; set; } = new();
    public List<EventDto> Events { get; set; } = new();
}

public class EventDetailsViewModel
{
    public EventDto Event { get; set; } = new();
    public List<CategoryDto> Categories { get; set; } = new();
    public EnrolmentDto? MyEnrolment { get; set; }
}

public class DashboardViewModel
{
    public List<EventDto> Events { get; set; } = new();
    public int TotalEvents => Events.Count;
    public int TotalEnrolments => Events.Sum(e => e.EnrolmentCount);
    public List<EventDto> Upcoming => Events.Where(e => e.Date >= DateTime.Today).OrderBy(e => e.Date).ToList();
}

/// <summary>Used by the Categories / Enrolments / Results pages: pick an event, then work on it.</summary>
public class EventPickerViewModel
{
    public string Action { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public List<EventDto> Events { get; set; } = new();
    public EventDto? Selected { get; set; }
}

public class CategoriesViewModel : EventPickerViewModel
{
    public List<CategoryDto> Categories { get; set; } = new();
}

public class EnrolmentsViewModel : EventPickerViewModel
{
    public List<EnrolmentDto> Enrolments { get; set; } = new();
}

public class ResultRow
{
    public EnrolmentDto Enrolment { get; set; } = new();
    public ResultDto? Result { get; set; }
}

public class ResultsViewModel : EventPickerViewModel
{
    public List<ResultRow> Rows { get; set; } = new();
}

using System.Net;

namespace RaceDay.Web.Services;

public class ApiResult<T>
{
    public bool Success { get; private init; }
    public T? Data { get; private init; }
    public string Error { get; private init; } = string.Empty;
    public HttpStatusCode? StatusCode { get; private init; }

    /// <summary>True when the API says the token is missing or expired.</summary>
    public bool IsUnauthorized => StatusCode == HttpStatusCode.Unauthorized;

    public static ApiResult<T> Ok(T? data) => new() { Success = true, Data = data };

    public static ApiResult<T> Fail(string error, HttpStatusCode? status = null) =>
        new() { Success = false, Error = error, StatusCode = status };
}

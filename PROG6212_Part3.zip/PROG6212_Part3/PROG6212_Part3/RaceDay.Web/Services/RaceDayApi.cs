using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using RaceDay.Web.Models;

namespace RaceDay.Web.Services;

/// <summary>Every piece of data in the MVC app comes through this class, which calls the Part 2 API.</summary>
public interface IRaceDayApi
{
    Task<ApiResult<LoginDto>> LoginAsync(string email, string password);
    Task<ApiResult<MessageDto>> RegisterAsync(RegisterViewModel model);

    Task<ApiResult<ProfileDto>> GetProfileAsync();
    Task<ApiResult<MessageDto>> UpdateProfileAsync(ProfileViewModel model);
    Task<ApiResult<ImageDto>> UploadProfilePictureAsync(IFormFile file);

    Task<ApiResult<List<EventDto>>> GetEventsAsync(EventFilter? filter = null);
    Task<ApiResult<List<EventDto>>> GetMyEventsAsync();
    Task<ApiResult<EventDto>> GetEventAsync(int id);
    Task<ApiResult<EventDto>> CreateEventAsync(EventFormViewModel model);
    Task<ApiResult<EventDto>> UpdateEventAsync(int id, EventFormViewModel model);
    Task<ApiResult<MessageDto>> DeleteEventAsync(int id);
    Task<ApiResult<ImageDto>> UploadBannerAsync(int eventId, IFormFile file);

    Task<ApiResult<List<CategoryDto>>> GetCategoriesAsync(int eventId);
    Task<ApiResult<CategoryDto>> AddCategoryAsync(int eventId, string name);
    Task<ApiResult<MessageDto>> DeleteCategoryAsync(int categoryId);

    Task<ApiResult<EnrolResultDto>> EnrolAsync(int eventId, int categoryId);
    Task<ApiResult<MessageDto>> WithdrawAsync(int eventId);
    Task<ApiResult<List<EnrolmentDto>>> GetMyEnrolmentsAsync();
    Task<ApiResult<List<EnrolmentDto>>> GetEventEnrolmentsAsync(int eventId);
    Task<ApiResult<MessageDto>> SetEnrolmentStatusAsync(int eventId, int enrolmentId, EnrolmentStatus status);

    Task<ApiResult<List<ResultDto>>> GetEventResultsAsync(int eventId);
    Task<ApiResult<MessageDto>> RecordResultAsync(int eventId, int bibNumber, TimeSpan finishTime, int position);
    Task<ApiResult<List<ResultDto>>> GetMyResultsAsync();

    Task<MediaFile?> GetMediaAsync(string path);
}

public class RaceDayApi : IRaceDayApi
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        Converters = { new JsonStringEnumConverter() }
    };

    private readonly HttpClient _http;
    private readonly ISessionUser _session;
    private readonly ILogger<RaceDayApi> _logger;

    public RaceDayApi(HttpClient http, ISessionUser session, ILogger<RaceDayApi> logger)
    {
        _http = http;
        _session = session;
        _logger = logger;
    }

    // ---------- Auth ----------
    public Task<ApiResult<LoginDto>> LoginAsync(string email, string password) =>
        SendAsync<LoginDto>(HttpMethod.Post, "api/auth/login", Body(new { email, password }));

    public Task<ApiResult<MessageDto>> RegisterAsync(RegisterViewModel m) =>
        SendAsync<MessageDto>(HttpMethod.Post, "api/auth/register", Body(new
        {
            name = m.Name,
            surname = m.Surname,
            email = m.Email,
            password = m.Password,
            role = m.Role,
            organiserCode = m.Role == "Organiser" ? m.OrganiserCode : null,
            emergencyContact = m.EmergencyContact,
            dateOfBirth = m.DateOfBirth
        }));

    // ---------- Profile ----------
    public Task<ApiResult<ProfileDto>> GetProfileAsync() =>
        SendAsync<ProfileDto>(HttpMethod.Get, "api/users/profile");

    public Task<ApiResult<MessageDto>> UpdateProfileAsync(ProfileViewModel m) =>
        SendAsync<MessageDto>(HttpMethod.Put, "api/users/profile", Body(new
        {
            name = m.Name,
            surname = m.Surname,
            emergencyContact = m.EmergencyContact ?? string.Empty,
            dateOfBirth = m.DateOfBirth
        }));

    public Task<ApiResult<ImageDto>> UploadProfilePictureAsync(IFormFile file) =>
        SendAsync<ImageDto>(HttpMethod.Post, "api/users/profile/picture", FileBody(file));

    // ---------- Events ----------
    public Task<ApiResult<List<EventDto>>> GetEventsAsync(EventFilter? filter = null)
    {
        var query = new List<string>();
        if (!string.IsNullOrWhiteSpace(filter?.Search)) query.Add($"search={Uri.EscapeDataString(filter!.Search!.Trim())}");
        if (filter?.Type is { } type) query.Add($"type={type}");
        if (filter?.From is { } from) query.Add($"from={Uri.EscapeDataString(from.ToString("yyyy-MM-dd'T'HH:mm:ss", CultureInfo.InvariantCulture))}");
        if (filter?.To is { } to) query.Add($"to={Uri.EscapeDataString(to.ToString("yyyy-MM-dd'T'HH:mm:ss", CultureInfo.InvariantCulture))}");
        var url = "api/events" + (query.Count > 0 ? "?" + string.Join("&", query) : string.Empty);
        return SendAsync<List<EventDto>>(HttpMethod.Get, url);
    }

    public Task<ApiResult<List<EventDto>>> GetMyEventsAsync() =>
        SendAsync<List<EventDto>>(HttpMethod.Get, "api/events/mine");

    public Task<ApiResult<EventDto>> GetEventAsync(int id) =>
        SendAsync<EventDto>(HttpMethod.Get, $"api/events/{id}");

    public Task<ApiResult<EventDto>> CreateEventAsync(EventFormViewModel m) =>
        SendAsync<EventDto>(HttpMethod.Post, "api/events", Body(EventBody(m)));

    public Task<ApiResult<EventDto>> UpdateEventAsync(int id, EventFormViewModel m) =>
        SendAsync<EventDto>(HttpMethod.Put, $"api/events/{id}", Body(EventBody(m)));

    public Task<ApiResult<MessageDto>> DeleteEventAsync(int id) =>
        SendAsync<MessageDto>(HttpMethod.Delete, $"api/events/{id}");

    public Task<ApiResult<ImageDto>> UploadBannerAsync(int eventId, IFormFile file) =>
        SendAsync<ImageDto>(HttpMethod.Post, $"api/events/{eventId}/banner", FileBody(file));

    private static object EventBody(EventFormViewModel m) => new
    {
        name = m.Name,
        description = m.Description ?? string.Empty,
        date = m.Date,
        location = m.Location,
        distanceKm = m.DistanceKm,
        type = m.Type
    };

    // ---------- Categories ----------
    public Task<ApiResult<List<CategoryDto>>> GetCategoriesAsync(int eventId) =>
        SendAsync<List<CategoryDto>>(HttpMethod.Get, $"api/events/{eventId}/categories");

    public Task<ApiResult<CategoryDto>> AddCategoryAsync(int eventId, string name) =>
        SendAsync<CategoryDto>(HttpMethod.Post, $"api/events/{eventId}/categories", Body(new { name }));

    public Task<ApiResult<MessageDto>> DeleteCategoryAsync(int categoryId) =>
        SendAsync<MessageDto>(HttpMethod.Delete, $"api/categories/{categoryId}");

    // ---------- Enrolments ----------
    public Task<ApiResult<EnrolResultDto>> EnrolAsync(int eventId, int categoryId) =>
        SendAsync<EnrolResultDto>(HttpMethod.Post, $"api/events/{eventId}/enrol", Body(new { categoryId }));

    public Task<ApiResult<MessageDto>> WithdrawAsync(int eventId) =>
        SendAsync<MessageDto>(HttpMethod.Delete, $"api/events/{eventId}/enrol");

    public Task<ApiResult<List<EnrolmentDto>>> GetMyEnrolmentsAsync() =>
        SendAsync<List<EnrolmentDto>>(HttpMethod.Get, "api/enrolments/me");

    public Task<ApiResult<List<EnrolmentDto>>> GetEventEnrolmentsAsync(int eventId) =>
        SendAsync<List<EnrolmentDto>>(HttpMethod.Get, $"api/events/{eventId}/enrolments");

    public Task<ApiResult<MessageDto>> SetEnrolmentStatusAsync(int eventId, int enrolmentId, EnrolmentStatus status) =>
        SendAsync<MessageDto>(HttpMethod.Put, $"api/events/{eventId}/enrolments/{enrolmentId}/status", Body(new { status }));

    // ---------- Results ----------
    public Task<ApiResult<List<ResultDto>>> GetEventResultsAsync(int eventId) =>
        SendAsync<List<ResultDto>>(HttpMethod.Get, $"api/events/{eventId}/results");

    public Task<ApiResult<MessageDto>> RecordResultAsync(int eventId, int bibNumber, TimeSpan finishTime, int position) =>
        SendAsync<MessageDto>(HttpMethod.Post, $"api/events/{eventId}/results",
            Body(new { bibNumber, finishTime = finishTime.ToString(@"hh\:mm\:ss"), position }));

    public Task<ApiResult<List<ResultDto>>> GetMyResultsAsync() =>
        SendAsync<List<ResultDto>>(HttpMethod.Get, "api/results/me");

    // ---------- Images (fetched through the API, always through the API) ----------
    public async Task<MediaFile?> GetMediaAsync(string path)
    {
        try
        {
            using var response = await _http.GetAsync("api/media/" + path);
            if (!response.IsSuccessStatusCode) return null;
            return new MediaFile
            {
                Data = await response.Content.ReadAsByteArrayAsync(),
                ContentType = response.Content.Headers.ContentType?.ToString() ?? "application/octet-stream"
            };
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            _logger.LogWarning(ex, "Could not load image {Path}", path);
            return null;
        }
    }

    // ---------- Plumbing ----------
    private static HttpContent Body(object body) =>
        new StringContent(JsonSerializer.Serialize(body, Json), Encoding.UTF8, "application/json");

    private static HttpContent FileBody(IFormFile file)
    {
        var content = new MultipartFormDataContent();
        var stream = new StreamContent(file.OpenReadStream());
        stream.Headers.ContentType = new MediaTypeHeaderValue(string.IsNullOrWhiteSpace(file.ContentType) ? "application/octet-stream" : file.ContentType);
        content.Add(stream, "file", file.FileName);
        return content;
    }

    private async Task<ApiResult<T>> SendAsync<T>(HttpMethod method, string url, HttpContent? content = null)
    {
        try
        {
            using var request = new HttpRequestMessage(method, url) { Content = content };
            if (!string.IsNullOrEmpty(_session.Token))
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _session.Token);

            using var response = await _http.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                var data = await response.Content.ReadFromJsonAsync<T>(Json);
                return ApiResult<T>.Ok(data);
            }

            return ApiResult<T>.Fail(await ReadErrorAsync(response), response.StatusCode);
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            _logger.LogError(ex, "RaceDay API call failed: {Method} {Url}", method, url);
            return ApiResult<T>.Fail("We couldn't reach the RaceDay server. Please try again in a moment.");
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "Unexpected response from {Url}", url);
            return ApiResult<T>.Fail("Something went wrong while reading the server's reply. Please try again.");
        }
    }

    /// <summary>Turns an API error into a short, friendly sentence. Raw errors are never shown to users.</summary>
    private static async Task<string> ReadErrorAsync(HttpResponseMessage response)
    {
        try
        {
            var text = await response.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(text);
            var root = doc.RootElement;
            if (root.ValueKind == JsonValueKind.Object)
            {
                if (root.TryGetProperty("message", out var message) && message.ValueKind == JsonValueKind.String)
                    return message.GetString()!;

                if (root.TryGetProperty("errors", out var errors) && errors.ValueKind == JsonValueKind.Object)
                {
                    var messages = errors.EnumerateObject()
                        .SelectMany(p => p.Value.EnumerateArray().Select(x => x.GetString()))
                        .Where(s => !string.IsNullOrWhiteSpace(s));
                    var joined = string.Join(" ", messages);
                    if (joined.Length > 0) return joined;
                }
            }
        }
        catch (Exception)
        {
            // fall through to the generic messages below
        }

        return response.StatusCode switch
        {
            HttpStatusCode.Unauthorized => "Your session has expired. Please log in again.",
            HttpStatusCode.Forbidden => "You don't have permission to do that.",
            HttpStatusCode.NotFound => "We couldn't find what you were looking for.",
            HttpStatusCode.RequestEntityTooLarge => "That file is too large.",
            HttpStatusCode.BadRequest => "Some of the information you entered isn't valid. Please check it and try again.",
            _ => "Something went wrong on the server. Please try again."
        };
    }
}

namespace RaceDay.Web.Services;

/// <summary>The logged-in user, kept in server-side session state (token, role, name).</summary>
public interface ISessionUser
{
    bool IsAuthenticated { get; }
    string? Token { get; }
    string? Role { get; }
    string DisplayName { get; }
    bool IsOrganiser { get; }
    bool IsParticipant { get; }
    void SignIn(string token, string role, string displayName, DateTime expiresAtUtc);
    void SignOut();
}

public class SessionUser : ISessionUser
{
    private const string TokenKey = "raceday.token";
    private const string RoleKey = "raceday.role";
    private const string NameKey = "raceday.name";
    private const string ExpiresKey = "raceday.expires";

    private readonly IHttpContextAccessor _accessor;

    public SessionUser(IHttpContextAccessor accessor) => _accessor = accessor;

    private ISession? Session => _accessor.HttpContext?.Session;

    public string? Token => Session?.GetString(TokenKey);
    public string? Role => Session?.GetString(RoleKey);
    public string DisplayName => Session?.GetString(NameKey) ?? string.Empty;
    public bool IsOrganiser => IsAuthenticated && Role == "Organiser";
    public bool IsParticipant => IsAuthenticated && Role == "Participant";

    public bool IsAuthenticated
    {
        get
        {
            var session = Session;
            if (session is null || string.IsNullOrEmpty(session.GetString(TokenKey))) return false;

            // An expired token is treated as "logged out".
            if (long.TryParse(session.GetString(ExpiresKey), out var ticks) && new DateTime(ticks, DateTimeKind.Utc) <= DateTime.UtcNow)
            {
                session.Clear();
                return false;
            }
            return true;
        }
    }

    public void SignIn(string token, string role, string displayName, DateTime expiresAtUtc)
    {
        var session = Session ?? throw new InvalidOperationException("No session available");
        session.Clear();
        session.SetString(TokenKey, token);
        session.SetString(RoleKey, role);
        session.SetString(NameKey, displayName);
        session.SetString(ExpiresKey, DateTime.SpecifyKind(expiresAtUtc, DateTimeKind.Utc).Ticks.ToString());
    }

    public void SignOut() => Session?.Clear();
}

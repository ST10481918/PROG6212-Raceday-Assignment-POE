namespace RaceDay.Web.Services;

/// <summary>Small display helpers used by the views.</summary>
public static class Format
{
    /// <summary>1 -> 1st, 2 -> 2nd, 47 -> 47th, 112 -> 112th</summary>
    public static string Ordinal(int n)
    {
        var lastTwo = n % 100;
        if (lastTwo is >= 11 and <= 13) return $"{n}th";
        return (n % 10) switch
        {
            1 => $"{n}st",
            2 => $"{n}nd",
            3 => $"{n}rd",
            _ => $"{n}th"
        };
    }

    public static string Time(TimeSpan t) => t.ToString(@"hh\:mm\:ss");

    public static string TypeIcon(Models.EventType type) => type switch
    {
        Models.EventType.Run => "🏃",
        Models.EventType.Walk => "🚶",
        Models.EventType.Cycle => "🚴",
        _ => "🏁"
    };
}

using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

/// <summary>Pages that only Participants can see: my enrolments and my results.</summary>
[SessionAuthorize(Role = "Participant")]
public class ParticipantController : AppController
{
    public ParticipantController(IRaceDayApi api, ISessionUser currentUser) : base(api, currentUser) { }

    [HttpGet]
    public async Task<IActionResult> Enrolments()
    {
        var result = await Api.GetMyEnrolmentsAsync();
        if (HandleExpiredSession(result) is { } expired) return expired;
        if (!result.Success) FlashError(result.Error);

        return View(result.Data ?? new List<EnrolmentDto>());
    }

    [HttpPost]
    public async Task<IActionResult> Withdraw(int eventId)
    {
        var result = await Api.WithdrawAsync(eventId);
        if (HandleExpiredSession(result) is { } expired) return expired;

        if (result.Success) FlashSuccess("Your race entry has been withdrawn.");
        else FlashError(result.Error);

        return RedirectToAction(nameof(Enrolments));
    }

    /// <summary>Personal race history across all completed events.</summary>
    [HttpGet]
    public async Task<IActionResult> Results()
    {
        var result = await Api.GetMyResultsAsync();
        if (HandleExpiredSession(result) is { } expired) return expired;
        if (!result.Success) FlashError(result.Error);

        return View((result.Data ?? new List<ResultDto>()).OrderByDescending(r => r.EventDate).ToList());
    }
}

using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

/// <summary>
/// Shows uploaded images (banners, profile pictures). The picture is fetched from the Part 2 API,
/// so this app never reads the stored files directly.
/// </summary>
public class MediaController : Controller
{
    private readonly IRaceDayApi _api;

    public MediaController(IRaceDayApi api) => _api = api;

    [HttpGet("media/{**path}")]
    public async Task<IActionResult> Get(string path)
    {
        var media = await _api.GetMediaAsync(path);
        if (media is null) return NotFound();

        Response.Headers.CacheControl = "public,max-age=3600";
        return File(media.Data, media.ContentType);
    }
}

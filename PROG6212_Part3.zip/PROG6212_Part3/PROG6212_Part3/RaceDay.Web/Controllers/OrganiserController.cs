using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

/// <summary>Everything an Organiser can do. Participants are sent to the "access denied" page.</summary>
[SessionAuthorize(Role = "Organiser")]
public class OrganiserController : AppController
{
    private const long MaxImageBytes = 5 * 1024 * 1024;
    private static readonly Regex TimePattern = new(@"^\d{1,2}:[0-5]\d:[0-5]\d$", RegexOptions.Compiled);

    public OrganiserController(IRaceDayApi api, ISessionUser currentUser) : base(api, currentUser) { }

    // ================= Dashboard =================
    [HttpGet]
    public async Task<IActionResult> Dashboard()
    {
        var result = await Api.GetMyEventsAsync();
        if (HandleExpiredSession(result) is { } expired) return expired;
        if (!result.Success) FlashError(result.Error);

        return View(new DashboardViewModel { Events = result.Data ?? new List<EventDto>() });
    }

    // ================= Events =================
    [HttpGet]
    public async Task<IActionResult> Events()
    {
        var result = await Api.GetMyEventsAsync();
        if (HandleExpiredSession(result) is { } expired) return expired;
        if (!result.Success) FlashError(result.Error);

        return View(result.Data ?? new List<EventDto>());
    }

    [HttpGet]
    public IActionResult CreateEvent() => View("EventForm", new EventFormViewModel { Date = DateTime.Today.AddDays(30).AddHours(8) });

    [HttpPost]
    public async Task<IActionResult> CreateEvent(EventFormViewModel model)
    {
        ValidateBanner(model);
        if (!ModelState.IsValid) return View("EventForm", model);

        var created = await Api.CreateEventAsync(model);
        if (HandleExpiredSession(created) is { } expired) return expired;
        if (!created.Success || created.Data is null)
        {
            ModelState.AddModelError(string.Empty, created.Error);
            return View("EventForm", model);
        }

        if (model.Banner is { Length: > 0 })
        {
            var upload = await Api.UploadBannerAsync(created.Data.Id, model.Banner);
            if (!upload.Success)
            {
                FlashWarning($"Your event was created, but the banner could not be uploaded: {upload.Error}");
                return RedirectToAction(nameof(EditEvent), new { id = created.Data.Id });
            }
        }

        FlashSuccess($"'{created.Data.Name}' has been created.");
        return RedirectToAction(nameof(Events));
    }

    [HttpGet]
    public async Task<IActionResult> EditEvent(int id)
    {
        var result = await Api.GetEventAsync(id);
        if (HandleExpiredSession(result) is { } expired) return expired;
        if (!result.Success || result.Data is null)
        {
            FlashError(result.Error);
            return RedirectToAction(nameof(Events));
        }

        var e = result.Data;
        return View("EventForm", new EventFormViewModel
        {
            Id = e.Id,
            Name = e.Name,
            Description = e.Description,
            Date = e.Date,
            Location = e.Location,
            DistanceKm = e.DistanceKm,
            Type = e.Type,
            ExistingBanner = e.BannerImage
        });
    }

    [HttpPost]
    public async Task<IActionResult> EditEvent(int id, EventFormViewModel model)
    {
        model.Id = id;
        ValidateBanner(model);
        if (!ModelState.IsValid) return View("EventForm", model);

        var updated = await Api.UpdateEventAsync(id, model);
        if (HandleExpiredSession(updated) is { } expired) return expired;
        if (!updated.Success)
        {
            ModelState.AddModelError(string.Empty, updated.Error);
            return View("EventForm", model);
        }

        if (model.Banner is { Length: > 0 })
        {
            var upload = await Api.UploadBannerAsync(id, model.Banner);
            if (!upload.Success)
            {
                FlashWarning($"Your changes were saved, but the banner could not be uploaded: {upload.Error}");
                return RedirectToAction(nameof(EditEvent), new { id });
            }
        }

        FlashSuccess("Your changes have been saved.");
        return RedirectToAction(nameof(Events));
    }

    [HttpPost]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        var result = await Api.DeleteEventAsync(id);
        if (HandleExpiredSession(result) is { } expired) return expired;

        if (result.Success) FlashSuccess("The event has been deleted.");
        else FlashError(result.Error);

        return RedirectToAction(nameof(Events));
    }

    private void ValidateBanner(EventFormViewModel model)
    {
        if (model.Banner is null || model.Banner.Length == 0) return;

        if (model.Banner.Length > MaxImageBytes)
            ModelState.AddModelError(nameof(model.Banner), "The banner is too large. The maximum size is 5 MB.");

        var allowed = new[] { "image/jpeg", "image/png", "image/webp", "image/gif" };
        if (!allowed.Contains(model.Banner.ContentType, StringComparer.OrdinalIgnoreCase))
            ModelState.AddModelError(nameof(model.Banner), "Only JPG, PNG, WEBP or GIF images are allowed.");
    }

    // ================= Categories =================
    [HttpGet]
    public async Task<IActionResult> Categories(int? eventId)
    {
        var (model, redirect) = await BuildPicker<CategoriesViewModel>(nameof(Categories), "Categories", eventId);
        if (redirect is not null) return redirect;

        if (model.Selected is not null)
        {
            var categories = await Api.GetCategoriesAsync(model.Selected.Id);
            if (HandleExpiredSession(categories) is { } expired) return expired;
            if (!categories.Success) FlashError(categories.Error);
            model.Categories = categories.Data ?? new List<CategoryDto>();
        }
        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> AddCategory(int eventId, string? name)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            FlashError("Please enter a category name, for example 'Under 20' or '21km'.");
            return RedirectToAction(nameof(Categories), new { eventId });
        }

        var result = await Api.AddCategoryAsync(eventId, name.Trim());
        if (HandleExpiredSession(result) is { } expired) return expired;

        if (result.Success) FlashSuccess($"Category '{name.Trim()}' added.");
        else FlashError(result.Error);

        return RedirectToAction(nameof(Categories), new { eventId });
    }

    [HttpPost]
    public async Task<IActionResult> DeleteCategory(int eventId, int categoryId)
    {
        var result = await Api.DeleteCategoryAsync(categoryId);
        if (HandleExpiredSession(result) is { } expired) return expired;

        if (result.Success) FlashSuccess("Category deleted.");
        else FlashError(result.Error);

        return RedirectToAction(nameof(Categories), new { eventId });
    }

    // ================= Enrolments =================
    [HttpGet]
    public async Task<IActionResult> Enrolments(int? eventId)
    {
        var (model, redirect) = await BuildPicker<EnrolmentsViewModel>(nameof(Enrolments), "Enrolments", eventId);
        if (redirect is not null) return redirect;

        if (model.Selected is not null)
        {
            var enrolments = await Api.GetEventEnrolmentsAsync(model.Selected.Id);
            if (HandleExpiredSession(enrolments) is { } expired) return expired;
            if (!enrolments.Success) FlashError(enrolments.Error);
            model.Enrolments = enrolments.Data ?? new List<EnrolmentDto>();
        }
        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> SetStatus(int eventId, int enrolmentId, EnrolmentStatus status)
    {
        var result = await Api.SetEnrolmentStatusAsync(eventId, enrolmentId, status);
        if (HandleExpiredSession(result) is { } expired) return expired;

        if (result.Success) FlashSuccess($"Enrolment marked as {status}.");
        else FlashError(result.Error);

        return RedirectToAction(nameof(Enrolments), new { eventId });
    }

    // ================= Results =================
    [HttpGet]
    public async Task<IActionResult> Results(int? eventId)
    {
        var (model, redirect) = await BuildPicker<ResultsViewModel>(nameof(Results), "Results", eventId);
        if (redirect is not null) return redirect;

        if (model.Selected is not null)
        {
            var enrolments = await Api.GetEventEnrolmentsAsync(model.Selected.Id);
            if (HandleExpiredSession(enrolments) is { } expired) return expired;
            var results = await Api.GetEventResultsAsync(model.Selected.Id);

            if (!enrolments.Success) FlashError(enrolments.Error);
            else if (!results.Success) FlashError(results.Error);

            var byBib = (results.Data ?? new List<ResultDto>()).ToDictionary(r => r.BibNumber);
            model.Rows = (enrolments.Data ?? new List<EnrolmentDto>())
                .Select(e => new ResultRow { Enrolment = e, Result = byBib.GetValueOrDefault(e.BibNumber) })
                .OrderBy(r => r.Result?.Position ?? int.MaxValue)
                .ThenBy(r => r.Enrolment.BibNumber)
                .ToList();
        }
        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> RecordResult(int eventId, int bibNumber, string? finishTime, int position)
    {
        var timeText = finishTime?.Trim() ?? string.Empty;
        if (!TimePattern.IsMatch(timeText) || !TimeSpan.TryParse(timeText, System.Globalization.CultureInfo.InvariantCulture, out var time) || time <= TimeSpan.Zero)
        {
            FlashError("Please enter the finish time as hours:minutes:seconds, for example 01:45:30.");
            return RedirectToAction(nameof(Results), new { eventId });
        }
        if (position < 1)
        {
            FlashError("The finishing position must be 1 or higher.");
            return RedirectToAction(nameof(Results), new { eventId });
        }

        var result = await Api.RecordResultAsync(eventId, bibNumber, time, position);
        if (HandleExpiredSession(result) is { } expired) return expired;

        if (result.Success) FlashSuccess($"Result published for bib {bibNumber}.");
        else FlashError(result.Error);

        return RedirectToAction(nameof(Results), new { eventId });
    }

    // ================= Shared =================
    /// <summary>Loads the organiser's events for the "choose an event" drop-down and finds the selected one.</summary>
    private async Task<(T Model, IActionResult? Redirect)> BuildPicker<T>(string action, string title, int? eventId)
        where T : EventPickerViewModel, new()
    {
        var model = new T { Action = action, Title = title };

        var events = await Api.GetMyEventsAsync();
        if (HandleExpiredSession(events) is { } expired) return (model, expired);
        if (!events.Success) FlashError(events.Error);

        model.Events = events.Data ?? new List<EventDto>();

        if (eventId.HasValue)
        {
            model.Selected = model.Events.FirstOrDefault(e => e.Id == eventId.Value);
            if (model.Selected is null)
            {
                FlashError("That event could not be found among your events.");
                return (model, RedirectToAction(action));
            }
        }
        else if (model.Events.Count == 1)
        {
            model.Selected = model.Events[0];
        }

        return (model, null);
    }
}

using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class HomeController : AppController
{
    public HomeController(IRaceDayApi api, ISessionUser currentUser) : base(api, currentUser) { }

    /// <summary>Public home page: upcoming events with filtering options.</summary>
    public async Task<IActionResult> Index([FromQuery] EventFilter filter)
    {
        var apiFilter = new EventFilter
        {
            Search = filter.Search,
            Type = filter.Type,
            From = filter.From ?? (filter.IncludePast ? null : DateTime.Today),
            To = filter.To
        };

        var result = await Api.GetEventsAsync(apiFilter);
        if (!result.Success) FlashError(result.Error);

        return View(new HomeViewModel
        {
            Filter = filter,
            Events = result.Data ?? new List<EventDto>()
        });
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error(int? code)
    {
        ViewData["Title"] = "Oops";
        (ViewData["Heading"], ViewData["Message"]) = code switch
        {
            404 => ("Page not found", "We couldn't find the page you were looking for."),
            403 => ("Access denied", "You don't have permission to view that page."),
            _ => ("Something went wrong", "Sorry, something went wrong on our side. Please try again in a moment.")
        };
        Response.StatusCode = code ?? 500;
        return View();
    }
}

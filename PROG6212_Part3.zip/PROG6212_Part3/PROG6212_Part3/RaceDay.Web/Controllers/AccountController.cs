using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

public class AccountController : AppController
{
    private const long MaxImageBytes = 5 * 1024 * 1024;

    public AccountController(IRaceDayApi api, ISessionUser currentUser) : base(api, currentUser) { }

    // ---------- Login ----------
    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (CurrentUser.IsAuthenticated) return RedirectToHome();
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var login = await Api.LoginAsync(model.Email, model.Password);
        if (!login.Success || login.Data is null)
        {
            ModelState.AddModelError(string.Empty, login.Error);
            model.Password = string.Empty;
            return View(model);
        }

        // Keep the token and role in the session, then look up the user's name for the menu.
        CurrentUser.SignIn(login.Data.Token, login.Data.Role, string.Empty, login.Data.ExpiresAt);
        var profile = await Api.GetProfileAsync();
        if (profile.Success && profile.Data is not null)
            CurrentUser.SignIn(login.Data.Token, login.Data.Role, profile.Data.Name, login.Data.ExpiresAt);

        FlashSuccess("Welcome back! You're logged in.");

        if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            return Redirect(model.ReturnUrl);

        return RedirectToHome();
    }

    // ---------- Register ----------
    [HttpGet]
    public IActionResult Register()
    {
        if (CurrentUser.IsAuthenticated) return RedirectToHome();
        return View(new RegisterViewModel());
    }

    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (model.Role != "Participant" && model.Role != "Organiser")
            ModelState.AddModelError(nameof(model.Role), "Please choose a role");

        if (model.Role == "Organiser" && string.IsNullOrWhiteSpace(model.OrganiserCode))
            ModelState.AddModelError(nameof(model.OrganiserCode), "Organisers need the organiser code");

        if (!ModelState.IsValid) return View(model);

        var result = await Api.RegisterAsync(model);
        if (!result.Success)
        {
            ModelState.AddModelError(string.Empty, result.Error);
            return View(model);
        }

        FlashSuccess("Your account has been created. Please log in.");
        return RedirectToAction(nameof(Login));
    }

    // ---------- Logout ----------
    [HttpPost]
    public IActionResult Logout()
    {
        CurrentUser.SignOut();
        FlashSuccess("You've been logged out. See you at the next race!");
        return RedirectToAction("Index", "Home");
    }

    [HttpGet]
    public IActionResult AccessDenied() => View();

    // ---------- Profile (both roles) ----------
    [HttpGet, SessionAuthorize]
    public async Task<IActionResult> Profile()
    {
        var result = await Api.GetProfileAsync();
        if (HandleExpiredSession(result) is { } expired) return expired;
        if (!result.Success || result.Data is null)
        {
            FlashError(result.Error);
            return RedirectToHome();
        }

        return View(ToViewModel(result.Data));
    }

    [HttpPost, SessionAuthorize]
    public async Task<IActionResult> Profile(ProfileViewModel model)
    {
        if (!ModelState.IsValid)
        {
            await FillReadOnlyFields(model);
            return View(model);
        }

        var result = await Api.UpdateProfileAsync(model);
        if (HandleExpiredSession(result) is { } expired) return expired;
        if (!result.Success)
        {
            ModelState.AddModelError(string.Empty, result.Error);
            await FillReadOnlyFields(model);
            return View(model);
        }

        FlashSuccess("Your profile has been updated.");
        return RedirectToAction(nameof(Profile));
    }

    [HttpPost, SessionAuthorize]
    public async Task<IActionResult> UploadPicture(IFormFile? picture)
    {
        if (picture is null || picture.Length == 0)
        {
            FlashError("Please choose a picture to upload.");
            return RedirectToAction(nameof(Profile));
        }
        if (picture.Length > MaxImageBytes)
        {
            FlashError("That picture is too large. The maximum size is 5 MB.");
            return RedirectToAction(nameof(Profile));
        }

        var result = await Api.UploadProfilePictureAsync(picture);
        if (HandleExpiredSession(result) is { } expired) return expired;

        if (result.Success) FlashSuccess("Your profile picture has been updated.");
        else FlashError(result.Error);

        return RedirectToAction(nameof(Profile));
    }

    private static ProfileViewModel ToViewModel(ProfileDto dto) => new()
    {
        Name = dto.Name,
        Surname = dto.Surname,
        Email = dto.Email,
        Role = dto.Role,
        EmergencyContact = dto.EmergencyContact,
        DateOfBirth = dto.DateOfBirth,
        ProfilePicture = dto.ProfilePicture
    };

    private async Task FillReadOnlyFields(ProfileViewModel model)
    {
        var current = await Api.GetProfileAsync();
        if (current.Success && current.Data is not null)
        {
            model.Email = current.Data.Email;
            model.Role = current.Data.Role;
            model.ProfilePicture = current.Data.ProfilePicture;
        }
    }
}

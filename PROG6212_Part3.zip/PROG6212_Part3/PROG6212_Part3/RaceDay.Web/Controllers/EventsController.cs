using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Filters;
using RaceDay.Web.Models;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

/// <summary>Event detail page and enrolment (Participant).</summary>
public class EventsController : AppController
{
    public EventsController(IRaceDayApi api, ISessionUser currentUser) : base(api, currentUser) { }

    /// <summary>Full event information, banner image and available categories.</summary>
    [HttpGet, SessionAuthorize]
    public async Task<IActionResult> Details(int id)
    {
        var ev = await Api.GetEventAsync(id);
        if (HandleExpiredSession(ev) is { } expired) return expired;
        if (!ev.Success || ev.Data is null)
        {
            FlashError(ev.Error);
            return RedirectToAction("Index", "Home");
        }

        var categories = await Api.GetCategoriesAsync(id);
        if (!categories.Success) FlashError(categories.Error);

        var model = new EventDetailsViewModel
        {
            Event = ev.Data,
            Categories = categories.Data ?? new List<CategoryDto>()
        };

        if (CurrentUser.IsParticipant)
        {
            var mine = await Api.GetMyEnrolmentsAsync();
            model.MyEnrolment = mine.Data?.FirstOrDefault(e => e.EventId == id);
        }

        ViewData["Title"] = ev.Data.Name;
        return View(model);
    }

    /// <summary>Enrol the logged-in Participant. The enrolment is recorded in the system immediately.</summary>
    [HttpPost, SessionAuthorize(Role = "Participant")]
    public async Task<IActionResult> Enrol(int eventId, int categoryId)
    {
        if (categoryId <= 0)
        {
            FlashError("Please choose a category before enrolling.");
            return RedirectToAction(nameof(Details), new { id = eventId });
        }

        var result = await Api.EnrolAsync(eventId, categoryId);
        if (HandleExpiredSession(result) is { } expired) return expired;

        if (result.Success && result.Data is not null)
            FlashSuccess($"You're in! Your bib number is {result.Data.BibNumber}. Your enrolment is Pending until the organiser confirms it.");
        else
            FlashError(result.Error);

        return RedirectToAction(nameof(Details), new { id = eventId });
    }
}

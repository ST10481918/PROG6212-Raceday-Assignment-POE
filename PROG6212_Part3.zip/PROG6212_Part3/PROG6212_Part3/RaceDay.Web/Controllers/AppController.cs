using Microsoft.AspNetCore.Mvc;
using RaceDay.Web.Services;

namespace RaceDay.Web.Controllers;

/// <summary>Shared helpers for every controller in the MVC app.</summary>
public abstract class AppController : Controller
{
    protected readonly IRaceDayApi Api;
    protected readonly ISessionUser CurrentUser;

    protected AppController(IRaceDayApi api, ISessionUser currentUser)
    {
        Api = api;
        CurrentUser = currentUser;
    }

    protected void FlashSuccess(string message) => TempData["Success"] = message;
    protected void FlashError(string message) => TempData["Error"] = message;
    protected void FlashWarning(string message) => TempData["Warning"] = message;

    /// <summary>
    /// If the API says the token has expired, ends the session and returns a redirect to the login page.
    /// Returns null when everything is fine.
    /// </summary>
    protected IActionResult? HandleExpiredSession<T>(ApiResult<T> result)
    {
        if (!result.IsUnauthorized) return null;
        CurrentUser.SignOut();
        FlashError("Your session has expired. Please log in again.");
        return RedirectToAction("Login", "Account");
    }

    protected IActionResult RedirectToHome() =>
        CurrentUser.IsOrganiser
            ? RedirectToAction("Dashboard", "Organiser")
            : RedirectToAction("Index", "Home");
}

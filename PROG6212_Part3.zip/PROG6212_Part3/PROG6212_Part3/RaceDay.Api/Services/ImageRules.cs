using Microsoft.AspNetCore.Http;

namespace RaceDay.Api.Services;

/// <summary>Validation rules for uploaded images.</summary>
public static class ImageRules
{
    public const long MaxBytes = 5 * 1024 * 1024;
    public const long MaxRequestBytes = MaxBytes + 1024 * 1024;

    private static readonly Dictionary<string, string> Allowed = new(StringComparer.OrdinalIgnoreCase)
    {
        ["image/jpeg"] = ".jpg",
        ["image/png"] = ".png",
        ["image/webp"] = ".webp",
        ["image/gif"] = ".gif"
    };

    public static bool TryValidate(IFormFile? file, out string extension, out string error)
    {
        extension = string.Empty;
        error = string.Empty;

        if (file is null || file.Length == 0)
        {
            error = "Please choose an image file to upload";
            return false;
        }
        if (file.Length > MaxBytes)
        {
            error = "The image is too large. The maximum size is 5 MB";
            return false;
        }
        if (!Allowed.TryGetValue(file.ContentType ?? string.Empty, out var ext))
        {
            error = "Only JPG, PNG, WEBP or GIF images are allowed";
            return false;
        }

        extension = ext;
        return true;
    }
}

namespace RaceDay.Api.Services;

public record FileDownload(Stream Content, string ContentType);

/// <summary>All file handling goes through this interface. The MVC app never touches the files directly.</summary>
public interface IFileStorageService
{
    /// <summary>Saves an image and returns its stored name (e.g. events/ab12.jpg).</summary>
    Task<string> UploadAsync(Stream content, string contentType, string folder, string extension, CancellationToken ct = default);

    Task<FileDownload?> DownloadAsync(string blobName, CancellationToken ct = default);

    /// <summary>Deletes a stored image. Does nothing when the name is empty or the file does not exist.</summary>
    Task DeleteAsync(string? blobName, CancellationToken ct = default);
}

/// <summary>Stores uploaded images on disk under the API's wwwroot/uploads folder.</summary>
public class LocalFileStorageService : IFileStorageService
{
    private static readonly Dictionary<string, string> ContentTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        [".jpg"] = "image/jpeg",
        [".jpeg"] = "image/jpeg",
        [".png"] = "image/png",
        [".webp"] = "image/webp",
        [".gif"] = "image/gif"
    };

    private readonly string _root;

    public LocalFileStorageService(string uploadsRoot) => _root = Path.GetFullPath(uploadsRoot);

    public async Task<string> UploadAsync(Stream content, string contentType, string folder, string extension, CancellationToken ct = default)
    {
        var directory = Path.Combine(_root, folder);
        Directory.CreateDirectory(directory);

        var fileName = $"{Guid.NewGuid():N}{extension}";
        await using var file = new FileStream(Path.Combine(directory, fileName), FileMode.CreateNew, FileAccess.Write);
        await content.CopyToAsync(file, ct);

        return $"{folder}/{fileName}";
    }

    public Task<FileDownload?> DownloadAsync(string blobName, CancellationToken ct = default)
    {
        var path = Resolve(blobName);
        if (path is null || !File.Exists(path)) return Task.FromResult<FileDownload?>(null);

        var contentType = ContentTypes.GetValueOrDefault(Path.GetExtension(path), "application/octet-stream");
        Stream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        return Task.FromResult<FileDownload?>(new FileDownload(stream, contentType));
    }

    public Task DeleteAsync(string? blobName, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(blobName)) return Task.CompletedTask;

        var path = Resolve(blobName);
        if (path is not null && File.Exists(path)) File.Delete(path);
        return Task.CompletedTask;
    }

    /// <summary>Turns a stored name into a full path, refusing anything that escapes the uploads folder.</summary>
    private string? Resolve(string blobName)
    {
        var full = Path.GetFullPath(Path.Combine(_root, blobName));
        return full.StartsWith(_root + Path.DirectorySeparatorChar, StringComparison.Ordinal) ? full : null;
    }
}

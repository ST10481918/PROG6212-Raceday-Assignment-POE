using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.DTOs;

public class ProfileResponse
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Surname { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string? EmergencyContact { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public string? ProfilePicture { get; set; }
}

/// <summary>All fields optional: only the fields you send are changed.</summary>
public class UpdateProfileRequest
{
    [MaxLength(100)] public string? Name { get; set; }
    [MaxLength(100)] public string? Surname { get; set; }
    [MaxLength(50)] public string? EmergencyContact { get; set; }
    public DateTime? DateOfBirth { get; set; }
}

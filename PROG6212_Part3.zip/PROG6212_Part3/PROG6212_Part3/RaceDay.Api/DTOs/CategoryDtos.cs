using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.DTOs;

public class CategoryRequest
{
    [Required, MaxLength(100)] public string Name { get; set; } = string.Empty;
}

public class CategoryResponse
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public int EventId { get; set; }
}

public class ImageResponse
{
    /// <summary>Stored name of the image.</summary>
    public string Path { get; set; } = string.Empty;
}

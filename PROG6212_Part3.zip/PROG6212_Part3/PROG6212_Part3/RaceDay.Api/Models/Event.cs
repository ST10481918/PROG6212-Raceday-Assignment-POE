using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Models;

public class Event
{
    public int Id { get; set; }

    [Required, MaxLength(150)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(2000)]
    public string Description { get; set; } = string.Empty;

    public DateTime Date { get; set; }

    [Required, MaxLength(200)]
    public string Location { get; set; } = string.Empty;

    public double DistanceKm { get; set; }

    public EventType Type { get; set; }

    /// <summary>Stored name of the banner image in wwwroot/uploads (null when none).</summary>
    [MaxLength(300)]
    public string? BannerImage { get; set; }

    public int OrganiserId { get; set; }
    public User Organiser { get; set; } = null!;

    public List<Category> Categories { get; set; } = new();
    public List<Enrolment> Enrolments { get; set; } = new();
}

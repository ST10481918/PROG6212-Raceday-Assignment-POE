namespace RaceDay.Api.Models;

public enum UserRole
{
    Participant = 0,
    Organiser = 1
}

public enum EnrolmentStatus
{
    Pending = 0,
    Confirmed = 1
}

public enum EventType
{
    Run = 0,
    Walk = 1,
    Cycle = 2
}

/// <summary>Role names used in [Authorize(Roles = ...)] and in the JWT role claim.</summary>
public static class Roles
{
    public const string Participant = nameof(UserRole.Participant);
    public const string Organiser = nameof(UserRole.Organiser);
}

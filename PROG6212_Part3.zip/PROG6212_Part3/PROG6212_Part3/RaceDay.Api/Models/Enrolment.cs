namespace RaceDay.Api.Models;

/// <summary>Links a Participant, an Event and the chosen Category. Holds the racer bib number.</summary>
public class Enrolment
{
    public int Id { get; set; }

    public int UserId { get; set; }
    public User User { get; set; } = null!;

    public int EventId { get; set; }
    public Event Event { get; set; } = null!;

    public int CategoryId { get; set; }
    public Category Category { get; set; } = null!;

    public int BibNumber { get; set; }

    /// <summary>Pending when the participant enrols; an Organiser can mark it Confirmed.</summary>
    public EnrolmentStatus Status { get; set; } = EnrolmentStatus.Pending;

    public DateTime EnrolledAt { get; set; } = DateTime.UtcNow;

    public RaceResult? Result { get; set; }
}

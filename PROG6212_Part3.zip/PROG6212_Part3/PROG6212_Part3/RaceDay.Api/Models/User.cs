using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Models;

/// <summary>An account. Role decides whether the user is an Organiser or a Participant.</summary>
public class User
{
    public int Id { get; set; }

    [Required, MaxLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required, MaxLength(100)]
    public string Surname { get; set; } = string.Empty;

    [Required, MaxLength(200)]
    public string Email { get; set; } = string.Empty;

    /// <summary>PBKDF2 hash (iterations.salt.hash). The plain password is never stored.</summary>
    [Required]
    public string PasswordHash { get; set; } = string.Empty;

    public UserRole Role { get; set; }

    [MaxLength(50)]
    public string? EmergencyContact { get; set; }

    public DateTime? DateOfBirth { get; set; }

    /// <summary>Stored name of the profile picture in wwwroot/uploads (null when none).</summary>
    [MaxLength(300)]
    public string? ProfilePicture { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public List<Event> OrganisedEvents { get; set; } = new();
    public List<Enrolment> Enrolments { get; set; } = new();
}

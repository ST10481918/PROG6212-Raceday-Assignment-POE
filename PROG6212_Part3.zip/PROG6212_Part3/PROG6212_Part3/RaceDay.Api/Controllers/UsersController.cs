using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>The logged-in user's own profile. Available to both Organisers and Participants.</summary>
[Route("api/users/profile")]
[Authorize]
public class UsersController : ApiControllerBase
{
    private readonly AppDbContext _db;
    private readonly IFileStorageService _blobs;

    public UsersController(AppDbContext db, IFileStorageService blobs)
    {
        _db = db;
        _blobs = blobs;
    }

    /// <summary>Get my profile.</summary>
    /// <response code="200">The profile of the logged-in user.</response>
    /// <response code="401">No valid token.</response>
    [HttpGet]
    [ProducesResponseType(typeof(ProfileResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<ProfileResponse>> GetProfile()
    {
        var user = await _db.Users.FindAsync(CurrentUserId);
        if (user is null) return NotFound(new MessageResponse("User not found"));

        return Ok(new ProfileResponse
        {
            Id = user.Id,
            Name = user.Name,
            Surname = user.Surname,
            Email = user.Email,
            Role = user.Role.ToString(),
            EmergencyContact = user.EmergencyContact,
            DateOfBirth = user.DateOfBirth,
            ProfilePicture = user.ProfilePicture
        });
    }

    /// <summary>Update my profile.</summary>
    /// <remarks>Send only the fields you want to change: name, surname, emergencyContact, dateOfBirth. Email and role cannot be changed here.</remarks>
    /// <response code="200">Profile updated.</response>
    /// <response code="401">No valid token.</response>
    [HttpPut]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> UpdateProfile(UpdateProfileRequest request)
    {
        var user = await _db.Users.FindAsync(CurrentUserId);
        if (user is null) return NotFound(new MessageResponse("User not found"));

        if (!string.IsNullOrWhiteSpace(request.Name)) user.Name = request.Name.Trim();
        if (!string.IsNullOrWhiteSpace(request.Surname)) user.Surname = request.Surname.Trim();
        if (request.EmergencyContact is not null) user.EmergencyContact = request.EmergencyContact;
        if (request.DateOfBirth is not null) user.DateOfBirth = request.DateOfBirth;

        await _db.SaveChangesAsync();
        return Ok(new MessageResponse("Profile updated successfully"));
    }

    /// <summary>Upload or replace my profile picture.</summary>
    /// <remarks>Send a multipart/form-data request with one file field called "file". JPG, PNG, WEBP or GIF, max 5 MB. The image is saved in wwwroot/uploads.</remarks>
    /// <response code="200">Picture saved. Returns the stored image name.</response>
    /// <response code="400">Missing file, wrong file type or file too large.</response>
    /// <response code="401">No valid token.</response>
    [HttpPost("picture")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(ImageRules.MaxRequestBytes)]
    [ProducesResponseType(typeof(ImageResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<ImageResponse>> UploadPicture(IFormFile file)
    {
        var user = await _db.Users.FindAsync(CurrentUserId);
        if (user is null) return NotFound(new MessageResponse("User not found"));

        if (!ImageRules.TryValidate(file, out var extension, out var error))
            return BadRequest(new MessageResponse(error));

        await using var stream = file.OpenReadStream();
        var blobName = await _blobs.UploadAsync(stream, file.ContentType, "profiles", extension);

        var oldPicture = user.ProfilePicture;
        user.ProfilePicture = blobName;
        await _db.SaveChangesAsync();
        await _blobs.DeleteAsync(oldPicture);

        return Ok(new ImageResponse { Path = blobName });
    }
}

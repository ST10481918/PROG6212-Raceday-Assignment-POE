using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

/// <summary>Age or distance categories (e.g. Under 20, Senior, 10km, 21km). Each category belongs to one event.</summary>
[Route("api")]
[Authorize]
public class CategoriesController : ApiControllerBase
{
    private readonly AppDbContext _db;

    public CategoriesController(AppDbContext db) => _db = db;

    /// <summary>List every category across all events (both roles).</summary>
    /// <response code="200">A list of categories.</response>
    [HttpGet("categories")]
    [ProducesResponseType(typeof(IEnumerable<CategoryResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<CategoryResponse>>> GetAll()
    {
        var items = await _db.Categories.AsNoTracking()
            .OrderBy(c => c.EventId).ThenBy(c => c.Name)
            .Select(c => new CategoryResponse { Id = c.Id, Name = c.Name, EventId = c.EventId })
            .ToListAsync();
        return Ok(items);
    }

    /// <summary>List the categories of one event (both roles).</summary>
    /// <response code="200">A list of categories.</response>
    /// <response code="404">No event with that id.</response>
    [HttpGet("events/{eventId:int}/categories")]
    [ProducesResponseType(typeof(IEnumerable<CategoryResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<IEnumerable<CategoryResponse>>> GetForEvent(int eventId)
    {
        if (!await _db.Events.AnyAsync(e => e.Id == eventId))
            return NotFound(new MessageResponse("Event not found"));

        var items = await _db.Categories.AsNoTracking()
            .Where(c => c.EventId == eventId)
            .OrderBy(c => c.Name)
            .Select(c => new CategoryResponse { Id = c.Id, Name = c.Name, EventId = c.EventId })
            .ToListAsync();
        return Ok(items);
    }

    /// <summary>Add a category to an event (owning Organiser only).</summary>
    /// <remarks>Expects a name such as "Under 20" or "21km".</remarks>
    /// <response code="201">Category created.</response>
    /// <response code="403">Participant, or an Organiser who does not own the event.</response>
    /// <response code="404">No event with that id.</response>
    /// <response code="409">The event already has a category with that name.</response>
    [HttpPost("events/{eventId:int}/categories")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(CategoryResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<CategoryResponse>> Create(int eventId, CategoryRequest request)
    {
        var ev = await _db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.Id == eventId);
        if (ev is null) return NotFound(new MessageResponse("Event not found"));
        if (ev.OrganiserId != CurrentUserId) return Forbid();

        var name = request.Name.Trim();
        if (await _db.Categories.AnyAsync(c => c.EventId == eventId && c.Name == name))
            return Conflict(new MessageResponse("This event already has a category with that name"));

        var category = new Category { Name = name, EventId = eventId };
        _db.Categories.Add(category);
        await _db.SaveChangesAsync();

        return StatusCode(StatusCodes.Status201Created,
            new CategoryResponse { Id = category.Id, Name = category.Name, EventId = eventId });
    }

    /// <summary>Delete a category (owning Organiser only). Not allowed once participants have enrolled in it.</summary>
    /// <response code="200">Category deleted.</response>
    /// <response code="403">Participant, or an Organiser who does not own the event.</response>
    /// <response code="404">No category with that id.</response>
    /// <response code="409">Participants are already enrolled in this category.</response>
    [HttpDelete("categories/{id:int}")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(int id)
    {
        var category = await _db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.Id == id);
        if (category is null) return NotFound(new MessageResponse("Category not found"));
        if (category.Event.OrganiserId != CurrentUserId) return Forbid();

        if (await _db.Enrolments.AnyAsync(e => e.CategoryId == id))
            return Conflict(new MessageResponse("Participants are already enrolled in this category"));

        _db.Categories.Remove(category);
        await _db.SaveChangesAsync();
        return Ok(new MessageResponse("Category deleted successfully"));
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>Serves uploaded images (event banners and profile pictures) from the API's wwwroot/uploads folder.</summary>
[Route("api/media")]
[AllowAnonymous]
public class MediaController : ApiControllerBase
{
    private readonly IFileStorageService _blobs;

    public MediaController(IFileStorageService blobs) => _blobs = blobs;

    /// <summary>Download an image by its stored name, e.g. events/ab12cd.jpg.</summary>
    /// <response code="200">The image file.</response>
    /// <response code="404">No such image.</response>
    [HttpGet("{**blobName}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Get(string blobName)
    {
        var allowed = (blobName.StartsWith("events/") || blobName.StartsWith("profiles/")) && !blobName.Contains("..");
        if (!allowed) return NotFound(new MessageResponse("Image not found"));

        var download = await _blobs.DownloadAsync(blobName);
        if (download is null) return NotFound(new MessageResponse("Image not found"));

        return File(download.Content, download.ContentType);
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>Registration and login. These are the only endpoints (besides public event/result reads) that do not need a token.</summary>
[Route("api/auth")]
[AllowAnonymous]
public class AuthController : ApiControllerBase
{
    private readonly AppDbContext _db;
    private readonly IPasswordService _passwords;
    private readonly ITokenService _tokens;
    private readonly RegistrationSettings _registration;

    public AuthController(AppDbContext db, IPasswordService passwords, ITokenService tokens,
        IOptions<RegistrationSettings> registration)
    {
        _db = db;
        _passwords = passwords;
        _tokens = tokens;
        _registration = registration.Value;
    }

    /// <summary>Register a new Participant or Organiser account.</summary>
    /// <remarks>
    /// Expects name, surname, email, password (min 8 chars) and role (Participant or Organiser).
    /// Organiser accounts also need the secret organiserCode so nobody can make themselves an Organiser by accident or on purpose.
    /// The password is hashed before it is saved.
    /// </remarks>
    /// <response code="201">Account created.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="403">Organiser code missing or wrong.</response>
    /// <response code="409">Email already registered.</response>
    [HttpPost("register")]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Register(RegisterRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();

        if (request.Role == UserRole.Organiser &&
            (string.IsNullOrWhiteSpace(_registration.OrganiserCode) ||
             request.OrganiserCode != _registration.OrganiserCode))
        {
            return StatusCode(StatusCodes.Status403Forbidden,
                new MessageResponse("A valid organiser code is required to register as an Organiser"));
        }

        if (await _db.Users.AnyAsync(u => u.Email == email))
            return Conflict(new MessageResponse("An account with this email already exists"));

        var user = new User
        {
            Name = request.Name.Trim(),
            Surname = request.Surname.Trim(),
            Email = email,
            PasswordHash = _passwords.Hash(request.Password),
            Role = request.Role,
            EmergencyContact = request.EmergencyContact,
            DateOfBirth = request.DateOfBirth
        };

        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        return StatusCode(StatusCodes.Status201Created, new MessageResponse("Account created successfully"));
    }

    /// <summary>Log in and receive a JWT bearer token.</summary>
    /// <remarks>Send the token in the Authorization header as "Bearer {token}". The token carries the user's id and role.</remarks>
    /// <response code="200">Returns the token, the role and the expiry time.</response>
    /// <response code="401">Email or password is wrong.</response>
    [HttpPost("login")]
    [ProducesResponseType(typeof(LoginResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Email == email);

        if (user is null || !_passwords.Verify(request.Password, user.PasswordHash))
            return Unauthorized(new MessageResponse("Invalid email or password"));

        var token = _tokens.CreateToken(user);
        return Ok(new LoginResponse
        {
            Token = token.Token,
            Role = user.Role.ToString(),
            ExpiresAt = token.ExpiresAt
        });
    }
}

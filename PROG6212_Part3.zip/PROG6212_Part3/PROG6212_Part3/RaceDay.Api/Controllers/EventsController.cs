using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

/// <summary>Race day events. Anyone can view them; only the Organiser who owns an event can change or delete it.</summary>
[Route("api/events")]
public class EventsController : ApiControllerBase
{
    private readonly AppDbContext _db;
    private readonly IFileStorageService _blobs;

    public EventsController(AppDbContext db, IFileStorageService blobs)
    {
        _db = db;
        _blobs = blobs;
    }

    /// <summary>List events, soonest first, with optional filters.</summary>
    /// <remarks>
    /// Optional query string filters: search (matches name, location or description), type (Run, Walk or Cycle),
    /// from and to (dates, inclusive).
    /// </remarks>
    /// <response code="200">A list of events.</response>
    [HttpGet]
    [AllowAnonymous]
    [ProducesResponseType(typeof(IEnumerable<EventResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<EventResponse>>> GetAll(
        [FromQuery] string? search = null,
        [FromQuery] EventType? type = null,
        [FromQuery(Name = "from")] DateTime? dateFrom = null,
        [FromQuery(Name = "to")] DateTime? dateTo = null)
    {
        var query = _db.Events.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var text = search.Trim();
            query = query.Where(e => e.Name.Contains(text) || e.Location.Contains(text) || e.Description.Contains(text));
        }
        if (type.HasValue) query = query.Where(e => e.Type == type.Value);
        if (dateFrom.HasValue) query = query.Where(e => e.Date >= dateFrom.Value);
        if (dateTo.HasValue) query = query.Where(e => e.Date <= dateTo.Value);

        var events = await query.OrderBy(e => e.Date).ToListAsync();
        return Ok(events.Select(EventResponse.From));
    }

    /// <summary>List the events I created, with the number of enrolments for each (owning Organiser only).</summary>
    /// <response code="200">My events, soonest first.</response>
    /// <response code="403">Logged in as a Participant.</response>
    [HttpGet("mine")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(IEnumerable<EventResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<IEnumerable<EventResponse>>> GetMine()
    {
        var userId = CurrentUserId;
        var items = await _db.Events.AsNoTracking()
            .Where(e => e.OrganiserId == userId)
            .OrderBy(e => e.Date)
            .Select(e => new EventResponse
            {
                Id = e.Id,
                Name = e.Name,
                Description = e.Description,
                Date = e.Date,
                Location = e.Location,
                DistanceKm = e.DistanceKm,
                Type = e.Type,
                OrganiserId = e.OrganiserId,
                BannerImage = e.BannerImage,
                EnrolmentCount = e.Enrolments.Count
            })
            .ToListAsync();
        return Ok(items);
    }

    /// <summary>Get one event by id.</summary>
    /// <response code="200">The event.</response>
    /// <response code="404">No event with that id.</response>
    [HttpGet("{id:int}")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<EventResponse>> GetById(int id)
    {
        var ev = await _db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.Id == id);
        return ev is null ? NotFound(new MessageResponse("Event not found")) : Ok(EventResponse.From(ev));
    }

    /// <summary>Create an event (Organiser only).</summary>
    /// <remarks>Expects name, description, date, location, distanceKm and type (Run, Walk or Cycle). The logged-in Organiser becomes the owner. Upload a banner afterwards with POST /api/events/{id}/banner.</remarks>
    /// <response code="201">Event created.</response>
    /// <response code="401">Not logged in.</response>
    /// <response code="403">Logged in as a Participant.</response>
    [HttpPost]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<EventResponse>> Create(EventRequest request)
    {
        var ev = new Event
        {
            Name = request.Name.Trim(),
            Description = request.Description,
            Date = request.Date,
            Location = request.Location.Trim(),
            DistanceKm = request.DistanceKm,
            Type = request.Type,
            OrganiserId = CurrentUserId
        };

        _db.Events.Add(ev);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = ev.Id }, EventResponse.From(ev));
    }

    /// <summary>Update an event (owning Organiser only).</summary>
    /// <response code="200">Event updated.</response>
    /// <response code="403">Participant, or an Organiser who does not own this event.</response>
    /// <response code="404">No event with that id.</response>
    [HttpPut("{id:int}")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<EventResponse>> Update(int id, EventRequest request)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.Id == id);
        if (ev is null) return NotFound(new MessageResponse("Event not found"));
        if (ev.OrganiserId != CurrentUserId) return Forbid();

        ev.Name = request.Name.Trim();
        ev.Description = request.Description;
        ev.Date = request.Date;
        ev.Location = request.Location.Trim();
        ev.DistanceKm = request.DistanceKm;
        ev.Type = request.Type;

        await _db.SaveChangesAsync();
        return Ok(EventResponse.From(ev));
    }

    /// <summary>Delete an event (owning Organiser only). Its categories, enrolments, results and banner image are deleted too.</summary>
    /// <response code="200">Event deleted.</response>
    /// <response code="403">Participant, or an Organiser who does not own this event.</response>
    /// <response code="404">No event with that id.</response>
    [HttpDelete("{id:int}")]
    [Authorize(Roles = Roles.Organiser)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.Id == id);
        if (ev is null) return NotFound(new MessageResponse("Event not found"));
        if (ev.OrganiserId != CurrentUserId) return Forbid();

        var banner = ev.BannerImage;
        _db.Events.Remove(ev);
        await _db.SaveChangesAsync();
        await _blobs.DeleteAsync(banner);

        return Ok(new MessageResponse("Event deleted successfully"));
    }

    /// <summary>Upload or replace the banner image of an event (owning Organiser only).</summary>
    /// <remarks>Send a multipart/form-data request with one file field called "file". JPG, PNG, WEBP or GIF, max 5 MB. The image is saved in wwwroot/uploads.</remarks>
    /// <response code="200">Banner saved. Returns the stored image name.</response>
    /// <response code="400">Missing file, wrong file type or file too large.</response>
    /// <response code="403">Participant, or an Organiser who does not own this event.</response>
    /// <response code="404">No event with that id.</response>
    [HttpPost("{id:int}/banner")]
    [Authorize(Roles = Roles.Organiser)]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(ImageRules.MaxRequestBytes)]
    [ProducesResponseType(typeof(ImageResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(MessageResponse), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ImageResponse>> UploadBanner(int id, IFormFile file)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.Id == id);
        if (ev is null) return NotFound(new MessageResponse("Event not found"));
        if (ev.OrganiserId != CurrentUserId) return Forbid();

        if (!ImageRules.TryValidate(file, out var extension, out var error))
            return BadRequest(new MessageResponse(error));

        await using var stream = file.OpenReadStream();
        var blobName = await _blobs.UploadAsync(stream, file.ContentType, "events", extension);

        var oldBanner = ev.BannerImage;
        ev.BannerImage = blobName;
        await _db.SaveChangesAsync();
        await _blobs.DeleteAsync(oldBanner);

        return Ok(new ImageResponse { Path = blobName });
    }
}

using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Tests;

public static class TestHelpers
{
    public const string OrganiserCode = "TEST-ORG-CODE";

    /// <summary>A fresh in-memory database for every test, so tests never affect each other.</summary>
    public static AppDbContext NewDb()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        return new AppDbContext(options);
    }

    /// <summary>Pretend the given user is logged in (what the JWT middleware does in the real API).</summary>
    public static T WithUser<T>(this T controller, int userId, UserRole role) where T : ControllerBase
    {
        var identity = new ClaimsIdentity(new[]
        {
            new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
            new Claim(ClaimTypes.Role, role.ToString())
        }, "TestAuth");

        controller.ControllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext { User = new ClaimsPrincipal(identity) }
        };
        return controller;
    }

    public static IOptions<JwtSettings> JwtOptions() => Options.Create(new JwtSettings
    {
        Key = "unit-test-signing-key-that-is-long-enough-32+",
        Issuer = "RaceDay.Tests",
        Audience = "RaceDay.Tests",
        ExpiryMinutes = 5
    });

    public static IOptions<RegistrationSettings> RegistrationOptions() =>
        Options.Create(new RegistrationSettings { OrganiserCode = OrganiserCode });

    public static async Task<User> AddUser(AppDbContext db, UserRole role, string? email = null)
    {
        var user = new User
        {
            Name = role.ToString(),
            Surname = "Tester",
            Email = email ?? $"{Guid.NewGuid():N}@test.com",
            PasswordHash = "x",
            Role = role
        };
        db.Users.Add(user);
        await db.SaveChangesAsync();
        return user;
    }

    public static async Task<Event> AddEvent(AppDbContext db, int organiserId, int daysFromNow = 30)
    {
        var ev = new Event
        {
            Name = "Test 10km",
            Description = "A test event",
            Date = DateTime.UtcNow.AddDays(daysFromNow),
            Location = "Johannesburg",
            DistanceKm = 10,
            Type = EventType.Run,
            OrganiserId = organiserId
        };
        db.Events.Add(ev);
        await db.SaveChangesAsync();
        return ev;
    }

    public static async Task<Category> AddCategory(AppDbContext db, int eventId, string name = "Senior")
    {
        var category = new Category { Name = name, EventId = eventId };
        db.Categories.Add(category);
        await db.SaveChangesAsync();
        return category;
    }

    public static async Task<Enrolment> AddEnrolment(AppDbContext db, int userId, int eventId, int categoryId, int bib = 1001)
    {
        var enrolment = new Enrolment { UserId = userId, EventId = eventId, CategoryId = categoryId, BibNumber = bib };
        db.Enrolments.Add(enrolment);
        await db.SaveChangesAsync();
        return enrolment;
    }
}

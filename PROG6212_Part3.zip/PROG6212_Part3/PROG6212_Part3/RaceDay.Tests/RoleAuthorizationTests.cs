using System.Reflection;
using Microsoft.AspNetCore.Authorization;
using RaceDay.Api.Controllers;
using RaceDay.Api.Models;

namespace RaceDay.Tests;

/// <summary>
/// Checks that every endpoint carries the right [Authorize] / [AllowAnonymous] rule.
/// If someone removes or changes one of these attributes, these tests fail.
/// </summary>
public class RoleAuthorizationTests
{
    [Theory]
    [InlineData(typeof(EventsController), nameof(EventsController.Create))]
    [InlineData(typeof(EventsController), nameof(EventsController.Update))]
    [InlineData(typeof(EventsController), nameof(EventsController.Delete))]
    [InlineData(typeof(CategoriesController), nameof(CategoriesController.Create))]
    [InlineData(typeof(CategoriesController), nameof(CategoriesController.Delete))]
    [InlineData(typeof(EnrolmentsController), nameof(EnrolmentsController.GetForEvent))]
    [InlineData(typeof(ResultsController), nameof(ResultsController.Record))]
    public void OrganiserOnlyEndpoints_RequireOrganiserRole(Type controller, string action)
    {
        var attribute = controller.GetMethod(action)!.GetCustomAttributes<AuthorizeAttribute>().Single();
        Assert.Equal(Roles.Organiser, attribute.Roles);
    }

    [Theory]
    [InlineData(typeof(EnrolmentsController), nameof(EnrolmentsController.Enrol))]
    [InlineData(typeof(EnrolmentsController), nameof(EnrolmentsController.Withdraw))]
    [InlineData(typeof(EnrolmentsController), nameof(EnrolmentsController.GetMine))]
    [InlineData(typeof(ResultsController), nameof(ResultsController.GetMine))]
    public void ParticipantOnlyEndpoints_RequireParticipantRole(Type controller, string action)
    {
        var attribute = controller.GetMethod(action)!.GetCustomAttributes<AuthorizeAttribute>().Single();
        Assert.Equal(Roles.Participant, attribute.Roles);
    }

    [Theory]
    [InlineData(typeof(UsersController))]
    [InlineData(typeof(CategoriesController))]
    [InlineData(typeof(EnrolmentsController))]
    public void ProtectedControllers_RequireAuthentication(Type controller)
    {
        Assert.NotEmpty(controller.GetCustomAttributes<AuthorizeAttribute>());
    }

    [Theory]
    [InlineData(typeof(AuthController), nameof(AuthController.Register))]
    [InlineData(typeof(AuthController), nameof(AuthController.Login))]
    [InlineData(typeof(EventsController), nameof(EventsController.GetAll))]
    [InlineData(typeof(EventsController), nameof(EventsController.GetById))]
    [InlineData(typeof(ResultsController), nameof(ResultsController.GetForEvent))]
    public void PublicEndpoints_AllowAnonymousAccess(Type controller, string action)
    {
        var method = controller.GetMethod(action)!;
        var isAnonymous = method.GetCustomAttributes<AllowAnonymousAttribute>().Any()
                          || controller.GetCustomAttributes<AllowAnonymousAttribute>().Any();
        Assert.True(isAnonymous);
    }

    [Fact]
    public void NoEndpointAllowsBothRolesToWrite_EventManagementIsNotOpenToParticipants()
    {
        foreach (var name in new[] { nameof(EventsController.Create), nameof(EventsController.Update), nameof(EventsController.Delete) })
        {
            var roles = typeof(EventsController).GetMethod(name)!.GetCustomAttribute<AuthorizeAttribute>()!.Roles;
            Assert.DoesNotContain(Roles.Participant, roles!);
        }
    }
}

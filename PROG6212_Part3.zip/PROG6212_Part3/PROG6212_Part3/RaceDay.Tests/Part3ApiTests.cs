using RaceDay.Api.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Controllers;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Tests;

public static class FormFiles
{
    public static IFormFile Make(string contentType = "image/png", int size = 64, string fileName = "pic.png")
    {
        var stream = new MemoryStream(new byte[size]);
        return new FormFile(stream, 0, size, "file", fileName)
        {
            Headers = new HeaderDictionary(),
            ContentType = contentType
        };
    }
}

public class ImageRulesTests
{
    [Theory]
    [InlineData("image/jpeg", ".jpg")]
    [InlineData("image/png", ".png")]
    [InlineData("image/webp", ".webp")]
    [InlineData("image/gif", ".gif")]
    [InlineData("IMAGE/PNG", ".png")]
    public void AllowedTypes_AreAccepted(string contentType, string expectedExtension)
    {
        Assert.True(ImageRules.TryValidate(FormFiles.Make(contentType), out var ext, out _));
        Assert.Equal(expectedExtension, ext);
    }

    [Theory]
    [InlineData("application/pdf")]
    [InlineData("text/html")]
    [InlineData("application/x-msdownload")]
    [InlineData("")]
    public void OtherTypes_AreRejected(string contentType)
    {
        Assert.False(ImageRules.TryValidate(FormFiles.Make(contentType), out _, out var error));
        Assert.False(string.IsNullOrEmpty(error));
    }

    [Fact]
    public void EmptyOrMissingFile_IsRejected()
    {
        Assert.False(ImageRules.TryValidate(null, out _, out _));
        Assert.False(ImageRules.TryValidate(FormFiles.Make(size: 0), out _, out _));
    }

    [Fact]
    public void FileOverFiveMegabytes_IsRejected()
    {
        var big = FormFiles.Make(size: (int)ImageRules.MaxBytes + 1);
        Assert.False(ImageRules.TryValidate(big, out _, out var error));
        Assert.Contains("too large", error);
    }
}

public class BannerUploadTests
{
    [Fact]
    public async Task UploadBanner_OwningOrganiser_StoresBlobAndSavesName()
    {
        using var db = TestHelpers.NewDb();
        var blobs = new FakeFileStorage();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var controller = new EventsController(db, blobs).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.UploadBanner(ev.Id, FormFiles.Make());

        var body = Assert.IsType<ImageResponse>(Assert.IsType<OkObjectResult>(result.Result).Value);
        Assert.StartsWith("events/", body.Path);
        Assert.Contains(body.Path, blobs.Blobs.Keys);
        Assert.Equal(body.Path, (await db.Events.FindAsync(ev.Id))!.BannerImage);
    }

    [Fact]
    public async Task UploadBanner_ReplacingBanner_DeletesTheOldImage()
    {
        using var db = TestHelpers.NewDb();
        var blobs = new FakeFileStorage();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var controller = new EventsController(db, blobs).WithUser(org.Id, UserRole.Organiser);
        var first = Assert.IsType<ImageResponse>(Assert.IsType<OkObjectResult>((await controller.UploadBanner(ev.Id, FormFiles.Make())).Result).Value);

        await controller.UploadBanner(ev.Id, FormFiles.Make());

        Assert.Contains(first.Path, blobs.Deleted);
        Assert.DoesNotContain(first.Path, blobs.Blobs.Keys);
    }

    [Fact]
    public async Task UploadBanner_OtherOrganiser_IsForbidden_AndNothingIsStored()
    {
        using var db = TestHelpers.NewDb();
        var blobs = new FakeFileStorage();
        var owner = await TestHelpers.AddUser(db, UserRole.Organiser);
        var intruder = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, owner.Id);
        var controller = new EventsController(db, blobs).WithUser(intruder.Id, UserRole.Organiser);

        var result = await controller.UploadBanner(ev.Id, FormFiles.Make());

        Assert.IsType<ForbidResult>(result.Result);
        Assert.Empty(blobs.Blobs);
    }

    [Fact]
    public async Task UploadBanner_WrongFileType_Returns400_AndNothingIsStored()
    {
        using var db = TestHelpers.NewDb();
        var blobs = new FakeFileStorage();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var controller = new EventsController(db, blobs).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.UploadBanner(ev.Id, FormFiles.Make("application/pdf"));

        Assert.IsType<BadRequestObjectResult>(result.Result);
        Assert.Empty(blobs.Blobs);
        Assert.Null((await db.Events.FindAsync(ev.Id))!.BannerImage);
    }

    [Fact]
    public async Task UploadBanner_UnknownEvent_Returns404()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var controller = new EventsController(db, new FakeFileStorage()).WithUser(org.Id, UserRole.Organiser);

        Assert.IsType<NotFoundObjectResult>((await controller.UploadBanner(999, FormFiles.Make())).Result);
    }

    [Fact]
    public async Task DeleteEvent_AlsoDeletesTheBannerImage()
    {
        using var db = TestHelpers.NewDb();
        var blobs = new FakeFileStorage();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var controller = new EventsController(db, blobs).WithUser(org.Id, UserRole.Organiser);
        var banner = Assert.IsType<ImageResponse>(Assert.IsType<OkObjectResult>((await controller.UploadBanner(ev.Id, FormFiles.Make())).Result).Value);

        await controller.Delete(ev.Id);

        Assert.Contains(banner.Path, blobs.Deleted);
    }

    [Fact]
    public void BannerUpload_IsOrganiserOnly()
    {
        var attr = typeof(EventsController).GetMethod(nameof(EventsController.UploadBanner))!
            .GetCustomAttributes(typeof(Microsoft.AspNetCore.Authorization.AuthorizeAttribute), false)
            .Cast<Microsoft.AspNetCore.Authorization.AuthorizeAttribute>().Single();
        Assert.Equal(Roles.Organiser, attr.Roles);
    }
}

public class ProfilePictureTests
{
    [Fact]
    public async Task UploadPicture_SavesBlobNameOnTheUser()
    {
        using var db = TestHelpers.NewDb();
        var blobs = new FakeFileStorage();
        var user = await TestHelpers.AddUser(db, UserRole.Participant);
        var controller = new UsersController(db, blobs).WithUser(user.Id, UserRole.Participant);

        var result = await controller.UploadPicture(FormFiles.Make("image/jpeg", fileName: "me.jpg"));

        var body = Assert.IsType<ImageResponse>(Assert.IsType<OkObjectResult>(result.Result).Value);
        Assert.StartsWith("profiles/", body.Path);
        Assert.Equal(body.Path, (await db.Users.FindAsync(user.Id))!.ProfilePicture);
    }

    [Fact]
    public async Task UploadPicture_InvalidFile_Returns400()
    {
        using var db = TestHelpers.NewDb();
        var user = await TestHelpers.AddUser(db, UserRole.Participant);
        var controller = new UsersController(db, new FakeFileStorage()).WithUser(user.Id, UserRole.Participant);

        var result = await controller.UploadPicture(FormFiles.Make("text/plain"));

        Assert.IsType<BadRequestObjectResult>(result.Result);
    }

    [Fact]
    public async Task UploadPicture_OnlyChangesTheLoggedInUsersPicture()
    {
        using var db = TestHelpers.NewDb();
        var me = await TestHelpers.AddUser(db, UserRole.Participant);
        var other = await TestHelpers.AddUser(db, UserRole.Participant);
        var controller = new UsersController(db, new FakeFileStorage()).WithUser(me.Id, UserRole.Participant);

        await controller.UploadPicture(FormFiles.Make());

        Assert.NotNull((await db.Users.FindAsync(me.Id))!.ProfilePicture);
        Assert.Null((await db.Users.FindAsync(other.Id))!.ProfilePicture);
    }
}

public class MediaControllerTests
{
    [Fact]
    public async Task Get_ExistingImage_ReturnsFile()
    {
        var blobs = new FakeFileStorage();
        var name = await blobs.UploadAsync(new MemoryStream(new byte[] { 1, 2, 3 }), "image/png", "events", ".png");

        var result = await new MediaController(blobs).Get(name);

        var file = Assert.IsType<FileStreamResult>(result);
        Assert.Equal("image/png", file.ContentType);
    }

    [Fact]
    public async Task Get_MissingImage_Returns404()
    {
        var result = await new MediaController(new FakeFileStorage()).Get("events/missing.png");
        Assert.IsType<NotFoundObjectResult>(result);
    }

    [Theory]
    [InlineData("secrets/file.txt")]
    [InlineData("events/../secrets.txt")]
    public async Task Get_OutsideAllowedFolders_Returns404(string name)
    {
        var result = await new MediaController(new FakeFileStorage()).Get(name);
        Assert.IsType<NotFoundObjectResult>(result);
    }
}

public class EnrolmentStatusTests
{
    [Fact]
    public async Task NewEnrolment_StartsAsPending()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var runner = await TestHelpers.AddUser(db, UserRole.Participant);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var cat = await TestHelpers.AddCategory(db, ev.Id);
        var controller = new EnrolmentsController(db).WithUser(runner.Id, UserRole.Participant);

        await controller.Enrol(ev.Id, new EnrolRequest { CategoryId = cat.Id });

        Assert.Equal(EnrolmentStatus.Pending, (await db.Enrolments.SingleAsync()).Status);
    }

    [Fact]
    public async Task SetStatus_OwningOrganiser_ConfirmsTheEnrolment()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var runner = await TestHelpers.AddUser(db, UserRole.Participant);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var cat = await TestHelpers.AddCategory(db, ev.Id);
        var enrolment = await TestHelpers.AddEnrolment(db, runner.Id, ev.Id, cat.Id);
        var controller = new EnrolmentsController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.SetStatus(ev.Id, enrolment.Id, new UpdateEnrolmentStatusRequest { Status = EnrolmentStatus.Confirmed });

        Assert.IsType<OkObjectResult>(result);
        Assert.Equal(EnrolmentStatus.Confirmed, (await db.Enrolments.FindAsync(enrolment.Id))!.Status);
    }

    [Fact]
    public async Task SetStatus_OtherOrganiser_IsForbidden()
    {
        using var db = TestHelpers.NewDb();
        var owner = await TestHelpers.AddUser(db, UserRole.Organiser);
        var intruder = await TestHelpers.AddUser(db, UserRole.Organiser);
        var runner = await TestHelpers.AddUser(db, UserRole.Participant);
        var ev = await TestHelpers.AddEvent(db, owner.Id);
        var cat = await TestHelpers.AddCategory(db, ev.Id);
        var enrolment = await TestHelpers.AddEnrolment(db, runner.Id, ev.Id, cat.Id);
        var controller = new EnrolmentsController(db).WithUser(intruder.Id, UserRole.Organiser);

        var result = await controller.SetStatus(ev.Id, enrolment.Id, new UpdateEnrolmentStatusRequest { Status = EnrolmentStatus.Confirmed });

        Assert.IsType<ForbidResult>(result);
        Assert.Equal(EnrolmentStatus.Pending, (await db.Enrolments.FindAsync(enrolment.Id))!.Status);
    }

    [Fact]
    public async Task SetStatus_UnknownEnrolment_Returns404()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var controller = new EnrolmentsController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.SetStatus(ev.Id, 999, new UpdateEnrolmentStatusRequest { Status = EnrolmentStatus.Confirmed });

        Assert.IsType<NotFoundObjectResult>(result);
    }

    [Fact]
    public void SetStatus_IsOrganiserOnly()
    {
        var attr = typeof(EnrolmentsController).GetMethod(nameof(EnrolmentsController.SetStatus))!
            .GetCustomAttributes(typeof(Microsoft.AspNetCore.Authorization.AuthorizeAttribute), false)
            .Cast<Microsoft.AspNetCore.Authorization.AuthorizeAttribute>().Single();
        Assert.Equal(Roles.Organiser, attr.Roles);
    }
}

public class EventFilterAndDashboardTests
{
    private static async Task<(AppDbContext Db, User Org)> Seed()
    {
        var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        db.Events.AddRange(
            new Event { Name = "Soweto Marathon", Description = "Big run", Location = "Soweto", Date = DateTime.UtcNow.AddDays(10), DistanceKm = 42, Type = EventType.Run, OrganiserId = org.Id },
            new Event { Name = "Dam Cycle Tour", Description = "Scenic", Location = "Vaal Dam", Date = DateTime.UtcNow.AddDays(40), DistanceKm = 80, Type = EventType.Cycle, OrganiserId = org.Id },
            new Event { Name = "Charity Walk", Description = "Family fun", Location = "Sandton", Date = DateTime.UtcNow.AddDays(70), DistanceKm = 5, Type = EventType.Walk, OrganiserId = org.Id });
        await db.SaveChangesAsync();
        return (db, org);
    }

    private static List<EventResponse> Items(ActionResult<IEnumerable<EventResponse>> r) =>
        Assert.IsAssignableFrom<IEnumerable<EventResponse>>(Assert.IsType<OkObjectResult>(r.Result).Value).ToList();

    [Fact]
    public async Task GetAll_FilterByType_ReturnsOnlyThatType()
    {
        var (db, _) = await Seed();
        using var _db = db;

        var list = Items(await new EventsController(db, new FakeFileStorage()).GetAll(type: EventType.Cycle));

        Assert.Single(list);
        Assert.Equal("Dam Cycle Tour", list[0].Name);
    }

    [Fact]
    public async Task GetAll_Search_MatchesNameOrLocation()
    {
        var (db, _) = await Seed();
        using var _db = db;
        var controller = new EventsController(db, new FakeFileStorage());

        Assert.Single(Items(await controller.GetAll(search: "Marathon")));
        Assert.Single(Items(await controller.GetAll(search: "Sandton")));
        Assert.Empty(Items(await controller.GetAll(search: "Nowhere")));
    }

    [Fact]
    public async Task GetAll_DateRange_FiltersEvents()
    {
        var (db, _) = await Seed();
        using var _db = db;

        var list = Items(await new EventsController(db, new FakeFileStorage())
            .GetAll(dateFrom: DateTime.UtcNow.AddDays(30), dateTo: DateTime.UtcNow.AddDays(50)));

        Assert.Single(list);
        Assert.Equal("Dam Cycle Tour", list[0].Name);
    }

    [Fact]
    public async Task GetMine_ReturnsOnlyMyEvents_WithEnrolmentCounts()
    {
        var (db, org) = await Seed();
        using var _db = db;
        var otherOrg = await TestHelpers.AddUser(db, UserRole.Organiser);
        await TestHelpers.AddEvent(db, otherOrg.Id);
        var runner = await TestHelpers.AddUser(db, UserRole.Participant);
        var first = await db.Events.OrderBy(e => e.Date).FirstAsync(e => e.OrganiserId == org.Id);
        var cat = await TestHelpers.AddCategory(db, first.Id);
        await TestHelpers.AddEnrolment(db, runner.Id, first.Id, cat.Id);
        var controller = new EventsController(db, new FakeFileStorage()).WithUser(org.Id, UserRole.Organiser);

        var list = Items(await controller.GetMine());

        Assert.Equal(3, list.Count);
        Assert.All(list, e => Assert.Equal(org.Id, e.OrganiserId));
        Assert.Equal(1, list.Single(e => e.Id == first.Id).EnrolmentCount);
    }

    [Fact]
    public void GetMine_IsOrganiserOnly()
    {
        var attr = typeof(EventsController).GetMethod(nameof(EventsController.GetMine))!
            .GetCustomAttributes(typeof(Microsoft.AspNetCore.Authorization.AuthorizeAttribute), false)
            .Cast<Microsoft.AspNetCore.Authorization.AuthorizeAttribute>().Single();
        Assert.Equal(Roles.Organiser, attr.Roles);
    }
}

public class ResultTotalsTests
{
    [Fact]
    public async Task GetMine_IncludesPositionAndTotalFinishers()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var cat = await TestHelpers.AddCategory(db, ev.Id);
        var a = await TestHelpers.AddUser(db, UserRole.Participant);
        var b = await TestHelpers.AddUser(db, UserRole.Participant);
        var c = await TestHelpers.AddUser(db, UserRole.Participant);
        await TestHelpers.AddEnrolment(db, a.Id, ev.Id, cat.Id, 1001);
        await TestHelpers.AddEnrolment(db, b.Id, ev.Id, cat.Id, 1002);
        await TestHelpers.AddEnrolment(db, c.Id, ev.Id, cat.Id, 1003); // never finishes
        var organiser = new ResultsController(db).WithUser(org.Id, UserRole.Organiser);
        await organiser.Record(ev.Id, new RecordResultRequest { BibNumber = 1001, FinishTime = TimeSpan.FromMinutes(40), Position = 1 });
        await organiser.Record(ev.Id, new RecordResultRequest { BibNumber = 1002, FinishTime = TimeSpan.FromMinutes(45), Position = 2 });

        var result = await new ResultsController(db).WithUser(b.Id, UserRole.Participant).GetMine();

        var row = Assert.Single(Assert.IsAssignableFrom<IEnumerable<ResultResponse>>(Assert.IsType<OkObjectResult>(result.Result).Value));
        Assert.Equal(2, row.Position);
        Assert.Equal(2, row.TotalFinishers);
        Assert.Equal(ev.Date, row.EventDate);
    }
}

using RaceDay.Api.Services;

namespace RaceDay.Tests;

/// <summary>In-memory stand-in for file storage so tests never write to disk.</summary>
public class FakeFileStorage : IFileStorageService
{
    public Dictionary<string, (byte[] Data, string ContentType)> Blobs { get; } = new();
    public List<string> Deleted { get; } = new();

    public async Task<string> UploadAsync(Stream content, string contentType, string folder, string extension, CancellationToken ct = default)
    {
        using var ms = new MemoryStream();
        await content.CopyToAsync(ms, ct);
        var name = $"{folder}/{Guid.NewGuid():N}{extension}";
        Blobs[name] = (ms.ToArray(), contentType);
        return name;
    }

    public Task<FileDownload?> DownloadAsync(string blobName, CancellationToken ct = default)
    {
        if (!Blobs.TryGetValue(blobName, out var blob)) return Task.FromResult<FileDownload?>(null);
        return Task.FromResult<FileDownload?>(new FileDownload(new MemoryStream(blob.Data), blob.ContentType));
    }

    public Task DeleteAsync(string? blobName, CancellationToken ct = default)
    {
        if (!string.IsNullOrWhiteSpace(blobName))
        {
            Blobs.Remove(blobName);
            Deleted.Add(blobName);
        }
        return Task.CompletedTask;
    }
}

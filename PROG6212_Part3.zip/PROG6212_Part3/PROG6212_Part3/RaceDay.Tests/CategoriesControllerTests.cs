using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Controllers;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Tests;

public class CategoriesControllerTests
{
    [Fact]
    public async Task Create_OwnEvent_Returns201()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var controller = new CategoriesController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.Create(ev.Id, new CategoryRequest { Name = "Under 20" });

        Assert.Equal(201, Assert.IsType<ObjectResult>(result.Result).StatusCode);
        Assert.Equal("Under 20", (await db.Categories.SingleAsync()).Name);
    }

    [Fact]
    public async Task Create_OnAnotherOrganisersEvent_IsForbidden()
    {
        using var db = TestHelpers.NewDb();
        var owner = await TestHelpers.AddUser(db, UserRole.Organiser);
        var intruder = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, owner.Id);
        var controller = new CategoriesController(db).WithUser(intruder.Id, UserRole.Organiser);

        var result = await controller.Create(ev.Id, new CategoryRequest { Name = "Senior" });

        Assert.IsType<ForbidResult>(result.Result);
        Assert.Empty(db.Categories);
    }

    [Fact]
    public async Task Create_DuplicateNameInSameEvent_Returns409()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        await TestHelpers.AddCategory(db, ev.Id, "Senior");
        var controller = new CategoriesController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.Create(ev.Id, new CategoryRequest { Name = "Senior" });

        Assert.IsType<ConflictObjectResult>(result.Result);
    }

    [Fact]
    public async Task Create_UnknownEvent_Returns404()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var controller = new CategoriesController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.Create(999, new CategoryRequest { Name = "Senior" });

        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Theory]
    [InlineData(UserRole.Participant)]
    [InlineData(UserRole.Organiser)]
    public async Task GetForEvent_BothRolesCanViewCategories(UserRole role)
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        await TestHelpers.AddCategory(db, ev.Id, "10km");
        await TestHelpers.AddCategory(db, ev.Id, "21km");
        var viewer = await TestHelpers.AddUser(db, role);
        var controller = new CategoriesController(db).WithUser(viewer.Id, role);

        var result = await controller.GetForEvent(ev.Id);

        var list = Assert.IsAssignableFrom<IEnumerable<CategoryResponse>>(Assert.IsType<OkObjectResult>(result.Result).Value);
        Assert.Equal(2, list.Count());
    }

    [Fact]
    public async Task Delete_CategoryWithEnrolments_Returns409()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var runner = await TestHelpers.AddUser(db, UserRole.Participant);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var cat = await TestHelpers.AddCategory(db, ev.Id);
        await TestHelpers.AddEnrolment(db, runner.Id, ev.Id, cat.Id);
        var controller = new CategoriesController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.Delete(cat.Id);

        Assert.IsType<ConflictObjectResult>(result);
        Assert.Equal(1, await db.Categories.CountAsync());
    }

    [Fact]
    public async Task Delete_UnusedCategory_Succeeds()
    {
        using var db = TestHelpers.NewDb();
        var org = await TestHelpers.AddUser(db, UserRole.Organiser);
        var ev = await TestHelpers.AddEvent(db, org.Id);
        var cat = await TestHelpers.AddCategory(db, ev.Id);
        var controller = new CategoriesController(db).WithUser(org.Id, UserRole.Organiser);

        var result = await controller.Delete(cat.Id);

        Assert.IsType<OkObjectResult>(result);
        Assert.Empty(db.Categories);
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Controllers;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Tests;

public class AuthControllerTests
{
    private static AuthController Create(RaceDay.Api.Data.AppDbContext db) =>
        new(db, new PasswordService(), new TokenService(TestHelpers.JwtOptions()), TestHelpers.RegistrationOptions());

    private static RegisterRequest NewRequest(string email = "jane@test.com", UserRole role = UserRole.Participant, string? code = null) => new()
    {
        Name = "Jane",
        Surname = "Doe",
        Email = email,
        Password = "Password123!",
        Role = role,
        OrganiserCode = code
    };

    // ---------- Registration ----------

    [Fact]
    public async Task Register_Participant_Returns201_AndSavesUser()
    {
        using var db = TestHelpers.NewDb();

        var result = await Create(db).Register(NewRequest());

        var obj = Assert.IsType<ObjectResult>(result);
        Assert.Equal(201, obj.StatusCode);
        var saved = await db.Users.SingleAsync();
        Assert.Equal(UserRole.Participant, saved.Role);
    }

    [Fact]
    public async Task Register_StoresHashedPassword_NotThePlainText()
    {
        using var db = TestHelpers.NewDb();

        await Create(db).Register(NewRequest());

        var saved = await db.Users.SingleAsync();
        Assert.NotEqual("Password123!", saved.PasswordHash);
        Assert.True(new PasswordService().Verify("Password123!", saved.PasswordHash));
    }

    [Fact]
    public async Task Register_NormalisesEmailToLowerCase()
    {
        using var db = TestHelpers.NewDb();

        await Create(db).Register(NewRequest("  Jane@Test.COM "));

        Assert.Equal("jane@test.com", (await db.Users.SingleAsync()).Email);
    }

    [Fact]
    public async Task Register_DuplicateEmail_Returns409()
    {
        using var db = TestHelpers.NewDb();
        var controller = Create(db);
        await controller.Register(NewRequest("dup@test.com"));

        var result = await controller.Register(NewRequest("DUP@test.com"));

        Assert.IsType<ConflictObjectResult>(result);
        Assert.Equal(1, await db.Users.CountAsync());
    }

    [Fact]
    public async Task Register_Organiser_WithCorrectCode_Succeeds()
    {
        using var db = TestHelpers.NewDb();

        var result = await Create(db).Register(NewRequest("org@test.com", UserRole.Organiser, TestHelpers.OrganiserCode));

        Assert.Equal(201, Assert.IsType<ObjectResult>(result).StatusCode);
        Assert.Equal(UserRole.Organiser, (await db.Users.SingleAsync()).Role);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("WRONG-CODE")]
    public async Task Register_Organiser_WithMissingOrWrongCode_Returns403_AndSavesNothing(string? code)
    {
        using var db = TestHelpers.NewDb();

        var result = await Create(db).Register(NewRequest("org@test.com", UserRole.Organiser, code));

        Assert.Equal(403, Assert.IsType<ObjectResult>(result).StatusCode);
        Assert.Empty(db.Users);
    }

    // ---------- Login ----------

    [Fact]
    public async Task Login_WithCorrectCredentials_ReturnsTokenAndRole()
    {
        using var db = TestHelpers.NewDb();
        var controller = Create(db);
        await controller.Register(NewRequest("login@test.com"));

        var result = await controller.Login(new LoginRequest { Email = "login@test.com", Password = "Password123!" });

        var ok = Assert.IsType<OkObjectResult>(result);
        var body = Assert.IsType<LoginResponse>(ok.Value);
        Assert.False(string.IsNullOrWhiteSpace(body.Token));
        Assert.Equal("Participant", body.Role);
    }

    [Fact]
    public async Task Login_AsOrganiser_ReturnsOrganiserRole()
    {
        using var db = TestHelpers.NewDb();
        var controller = Create(db);
        await controller.Register(NewRequest("o@test.com", UserRole.Organiser, TestHelpers.OrganiserCode));

        var result = await controller.Login(new LoginRequest { Email = "o@test.com", Password = "Password123!" });

        var body = Assert.IsType<LoginResponse>(Assert.IsType<OkObjectResult>(result).Value);
        Assert.Equal("Organiser", body.Role);
    }

    [Fact]
    public async Task Login_WrongPassword_Returns401()
    {
        using var db = TestHelpers.NewDb();
        var controller = Create(db);
        await controller.Register(NewRequest("login@test.com"));

        var result = await controller.Login(new LoginRequest { Email = "login@test.com", Password = "nope" });

        Assert.IsType<UnauthorizedObjectResult>(result);
    }

    [Fact]
    public async Task Login_UnknownEmail_Returns401()
    {
        using var db = TestHelpers.NewDb();

        var result = await Create(db).Login(new LoginRequest { Email = "ghost@test.com", Password = "Password123!" });

        Assert.IsType<UnauthorizedObjectResult>(result);
    }
}

using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Tests;

public class PasswordServiceTests
{
    private readonly PasswordService _service = new();

    [Fact]
    public void Hash_DoesNotContainThePlainPassword()
    {
        var hash = _service.Hash("Secret123!");

        Assert.NotEqual("Secret123!", hash);
        Assert.DoesNotContain("Secret123!", hash);
    }

    [Fact]
    public void Hash_UsesADifferentSaltEveryTime()
    {
        Assert.NotEqual(_service.Hash("Secret123!"), _service.Hash("Secret123!"));
    }

    [Fact]
    public void Verify_ReturnsTrue_ForCorrectPassword()
    {
        var hash = _service.Hash("Secret123!");
        Assert.True(_service.Verify("Secret123!", hash));
    }

    [Fact]
    public void Verify_ReturnsFalse_ForWrongPassword()
    {
        var hash = _service.Hash("Secret123!");
        Assert.False(_service.Verify("secret123!", hash));
    }

    [Theory]
    [InlineData("")]
    [InlineData("not-a-hash")]
    [InlineData("1.2.3")]
    public void Verify_ReturnsFalse_ForMalformedHash(string badHash)
    {
        Assert.False(_service.Verify("Secret123!", badHash));
    }
}

public class TokenServiceTests
{
    [Theory]
    [InlineData(UserRole.Organiser)]
    [InlineData(UserRole.Participant)]
    public void CreateToken_ContainsUserIdAndRole(UserRole role)
    {
        var service = new TokenService(TestHelpers.JwtOptions());
        var user = new User { Id = 42, Name = "Jane", Surname = "Doe", Email = "jane@test.com", Role = role };

        var result = service.CreateToken(user);
        var parsed = new JwtSecurityTokenHandler().ReadJwtToken(result.Token);

        Assert.Equal("42", parsed.Claims.First(c => c.Type == ClaimTypes.NameIdentifier || c.Type == "nameid").Value);
        Assert.Equal(role.ToString(), parsed.Claims.First(c => c.Type == ClaimTypes.Role || c.Type == "role").Value);
    }

    [Fact]
    public void CreateToken_ExpiresInTheFuture()
    {
        var service = new TokenService(TestHelpers.JwtOptions());
        var result = service.CreateToken(new User { Id = 1, Name = "A", Surname = "B", Email = "a@b.com" });

        Assert.True(result.ExpiresAt > DateTime.UtcNow);
    }
}

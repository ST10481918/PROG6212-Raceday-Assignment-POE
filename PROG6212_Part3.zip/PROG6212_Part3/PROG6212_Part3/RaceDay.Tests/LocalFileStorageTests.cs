using RaceDay.Api.Services;

namespace RaceDay.Tests;

/// <summary>Tests the real wwwroot/uploads storage using a temporary folder.</summary>
public class LocalFileStorageTests : IDisposable
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), "raceday-tests-" + Guid.NewGuid().ToString("N"));
    private readonly LocalFileStorageService _storage;

    public LocalFileStorageTests() => _storage = new LocalFileStorageService(_root);

    public void Dispose()
    {
        if (Directory.Exists(_root)) Directory.Delete(_root, recursive: true);
    }

    private static MemoryStream Bytes(params byte[] data) => new(data);

    [Fact]
    public async Task Upload_SavesFileUnderTheFolder_AndReturnsItsName()
    {
        var name = await _storage.UploadAsync(Bytes(1, 2, 3), "image/png", "events", ".png");

        Assert.StartsWith("events/", name);
        Assert.EndsWith(".png", name);
        Assert.True(File.Exists(Path.Combine(_root, name.Replace('/', Path.DirectorySeparatorChar))));
    }

    [Fact]
    public async Task Download_ReturnsTheSameBytes_WithTheRightContentType()
    {
        var name = await _storage.UploadAsync(Bytes(9, 8, 7), "image/jpeg", "profiles", ".jpg");

        var download = await _storage.DownloadAsync(name);

        Assert.NotNull(download);
        Assert.Equal("image/jpeg", download!.ContentType);
        using var copy = new MemoryStream();
        await download.Content.CopyToAsync(copy);
        download.Content.Dispose();
        Assert.Equal(new byte[] { 9, 8, 7 }, copy.ToArray());
    }

    [Fact]
    public async Task Download_UnknownFile_ReturnsNull()
    {
        Assert.Null(await _storage.DownloadAsync("events/missing.png"));
    }

    [Theory]
    [InlineData("../secret.txt")]
    [InlineData("events/../../secret.txt")]
    public async Task Download_PathOutsideUploads_ReturnsNull(string name)
    {
        Assert.Null(await _storage.DownloadAsync(name));
    }

    [Fact]
    public async Task Delete_RemovesTheFile()
    {
        var name = await _storage.UploadAsync(Bytes(1), "image/png", "events", ".png");

        await _storage.DeleteAsync(name);

        Assert.Null(await _storage.DownloadAsync(name));
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("events/never-existed.png")]
    public async Task Delete_EmptyOrMissingName_DoesNotThrow(string? name)
    {
        await _storage.DeleteAsync(name);
    }
}
